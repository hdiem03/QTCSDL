﻿
namespace QLQuan
{
    partial class fBan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.txbTableNumber = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.txbtxbTableName1 = new System.Windows.Forms.TextBox();
            this.txbTableName = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.btnViewTable = new System.Windows.Forms.Button();
            this.btnEditTable = new System.Windows.Forms.Button();
            this.btnDeleteTable = new System.Windows.Forms.Button();
            this.btnAddTable = new System.Windows.Forms.Button();
            this.panel34 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel28.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.panel31);
            this.panel28.Controls.Add(this.panel32);
            this.panel28.Location = new System.Drawing.Point(470, 219);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(319, 121);
            this.panel28.TabIndex = 4;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.textBox5);
            this.panel31.Controls.Add(this.txbTableNumber);
            this.panel31.Location = new System.Drawing.Point(3, 55);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(313, 46);
            this.panel31.TabIndex = 2;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(148, 13);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(148, 22);
            this.textBox5.TabIndex = 1;
            // 
            // txbTableNumber
            // 
            this.txbTableNumber.AutoSize = true;
            this.txbTableNumber.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTableNumber.Location = new System.Drawing.Point(3, 11);
            this.txbTableNumber.Name = "txbTableNumber";
            this.txbTableNumber.Size = new System.Drawing.Size(83, 24);
            this.txbTableNumber.TabIndex = 0;
            this.txbTableNumber.Text = "Số bàn:";
            this.txbTableNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.txbtxbTableName1);
            this.panel32.Controls.Add(this.txbTableName);
            this.panel32.Location = new System.Drawing.Point(3, 3);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(313, 46);
            this.panel32.TabIndex = 1;
            // 
            // txbtxbTableName1
            // 
            this.txbtxbTableName1.Location = new System.Drawing.Point(148, 13);
            this.txbtxbTableName1.Name = "txbtxbTableName1";
            this.txbtxbTableName1.Size = new System.Drawing.Size(148, 22);
            this.txbtxbTableName1.TabIndex = 1;
            // 
            // txbTableName
            // 
            this.txbTableName.AutoSize = true;
            this.txbTableName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTableName.Location = new System.Drawing.Point(3, 11);
            this.txbTableName.Name = "txbTableName";
            this.txbTableName.Size = new System.Drawing.Size(86, 24);
            this.txbTableName.TabIndex = 0;
            this.txbTableName.Text = "Mã bàn:";
            this.txbTableName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.btnViewTable);
            this.panel33.Controls.Add(this.btnEditTable);
            this.panel33.Controls.Add(this.btnDeleteTable);
            this.panel33.Controls.Add(this.btnAddTable);
            this.panel33.Controls.Add(this.panel34);
            this.panel33.Location = new System.Drawing.Point(23, 137);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(441, 76);
            this.panel33.TabIndex = 5;
            // 
            // btnViewTable
            // 
            this.btnViewTable.Location = new System.Drawing.Point(354, 0);
            this.btnViewTable.Name = "btnViewTable";
            this.btnViewTable.Size = new System.Drawing.Size(75, 70);
            this.btnViewTable.TabIndex = 5;
            this.btnViewTable.Text = "Xem";
            this.btnViewTable.UseVisualStyleBackColor = true;
            // 
            // btnEditTable
            // 
            this.btnEditTable.Location = new System.Drawing.Point(237, 3);
            this.btnEditTable.Name = "btnEditTable";
            this.btnEditTable.Size = new System.Drawing.Size(75, 70);
            this.btnEditTable.TabIndex = 4;
            this.btnEditTable.Text = "Sửa";
            this.btnEditTable.UseVisualStyleBackColor = true;
            // 
            // btnDeleteTable
            // 
            this.btnDeleteTable.Location = new System.Drawing.Point(119, 3);
            this.btnDeleteTable.Name = "btnDeleteTable";
            this.btnDeleteTable.Size = new System.Drawing.Size(75, 70);
            this.btnDeleteTable.TabIndex = 3;
            this.btnDeleteTable.Text = "Xóa";
            this.btnDeleteTable.UseVisualStyleBackColor = true;
            // 
            // btnAddTable
            // 
            this.btnAddTable.Location = new System.Drawing.Point(3, 3);
            this.btnAddTable.Name = "btnAddTable";
            this.btnAddTable.Size = new System.Drawing.Size(75, 70);
            this.btnAddTable.TabIndex = 2;
            this.btnAddTable.Text = "Thêm";
            this.btnAddTable.UseVisualStyleBackColor = true;
            // 
            // panel34
            // 
            this.panel34.Location = new System.Drawing.Point(0, -116);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(441, 86);
            this.panel34.TabIndex = 1;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(18, 219);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(446, 261);
            this.dataGridView2.TabIndex = 7;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(261, 78);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(228, 17);
            this.label15.TabIndex = 49;
            this.label15.Text = "--------------------------------------------";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(308, 61);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(124, 17);
            this.label14.TabIndex = 48;
            this.label14.Text = "SĐT: 0978788799";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(273, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 17);
            this.label2.TabIndex = 47;
            this.label2.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(339, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 17);
            this.label1.TabIndex = 46;
            this.label1.Text = "DNG";
            // 
            // fBan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 494);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.panel33);
            this.Controls.Add(this.panel28);
            this.Name = "fBan";
            this.Text = "fBan";
            this.panel28.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label txbTableNumber;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TextBox txbtxbTableName1;
        private System.Windows.Forms.Label txbTableName;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Button btnViewTable;
        private System.Windows.Forms.Button btnEditTable;
        private System.Windows.Forms.Button btnDeleteTable;
        private System.Windows.Forms.Button btnAddTable;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}