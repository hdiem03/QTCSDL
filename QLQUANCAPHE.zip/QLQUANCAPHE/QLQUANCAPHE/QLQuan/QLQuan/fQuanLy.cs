﻿
using QLQuan.DAO;
using QLQuan.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuan
{
    public partial class fQuanLy : Form
    {
        public fQuanLy()
        {
            InitializeComponent();
            LoadTable();
        }
        #region Method
        void LoadTable()
        {
            List<Table> tableList = TableDAO.Instance.LoadDSBan();
            foreach(Table item in tableList)
            {
                Button btn = new Button() { Width = TableDAO.TableWildth, Height = TableDAO.TableHeight };
                btn.Text = item.MaBan+Environment.NewLine +item.SoBan;

                flpTable.Controls.Add(btn);
            

            }    
        }
        #endregion
        #region Events

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thôngTinCáNhânToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAccountProfile f = new fAccountProfile();
            f.ShowDialog();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void bánToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAdmin f = new fAdmin();
            f.ShowDialog();
        }
        #endregion
    }
}
