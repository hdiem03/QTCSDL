﻿create database Quanlycaphe
use Quanlycaphe
create table NHACUNGCAP(MaNCC char(10) primary key not null, 
						TenNCC nvarchar(50) not null,
						DiaChi nvarchar(100) not null,
						SDT varchar(10) not null)
create table HANGHOA (	MaHH char(6) primary key not null,
						TenHH nvarchar(100) not null, 
						DonViTinhHH nvarchar(15) not null,
						DonGiaHH numeric(15,0)not null)
create table MON (	TenMon nvarchar(100) primary key not null,
					GiaTien numeric(15,0) not null)
create table NHANVIEN  (	MaNV varchar(5) primary key not null, 
							TenNV nvarchar(100) not null)	
create table BAN (	MaBan varchar(4) primary key not null,
					SoBan int not null)
create table KHACHHANG ( MaKH char(5) primary key not null,
						TenKH nvarchar(50) not null)
create table MUA (	MaDatHang varchar(10) primary key not null,
					MaNCC char(10) foreign key references NHACUNGCAP not null,
					MaNV varchar(5) foreign key references NHANVIEN not null,
					NgayMuaHang date not null,
					TongTienHH numeric(15,0) null)
create table MUA_CHI_TIET (	MaDatHang varchar(10) foreign key references MUA not null,
					MaHH char(6) foreign key references HANGHOA not null,
					constraint PK_MUA_CHI_TIET primary key (MaDatHang,MaHH),
					SoLuongHH int not null,
					ThanhTienHH numeric(15,0) null)
create table THANH_TOAN_HD(	MaHoaDon varchar(13) primary key not null,
							MaBan varchar(4) foreign key references BAN not null,
							GioVao datetime not null,
							GioRa datetime not null,
							MaKH char(5) not null foreign key references KHACHHANG,
							MaNV varchar(5) not null foreign key references NHANVIEN,
							TongTien int null)

create table THANH_TOAN_HD_CHI_TIET(	MaHoaDon varchar(13) not null foreign key references THANH_TOAN_HD ,
										TenMon nvarchar(100) not null foreign key references MON ,
										constraint PK_THANH_TOAN_HD_CHI_TIET primary key (MaHoaDon,TenMon),
										SoLuong int not null,
										ThanhTien numeric(15,0) null)														


insert into NHACUNGCAP (MaNCC,TenNCC,DiaChi,SDT)
values
('NCC0000001',N'Mega Market',N'5 Cách Mạng Tháng 8, Hoà Cường Nam, Cẩm Lệ, Đà Nẵng','0236364493'),
('NCC0000002',N'Xưởng In Ly Nhựa Đà Nẵng',N'03 Phú Xuân 8, P. Hòa Minh, Q. Liên Chiểu, TP. Đà Nẵng','0906555903'),
('NCC0000003',N'Cô Xuân Trái Cây - Chợ Bắc Mỹ An',N'25 Nguyễn Bá Lân, Bắc Mỹ An, Ngũ Hành Sơn, Đà Nẵng','0236395451'),
('NCC0000004',N'Công ty Long Hiền',N'Lô D2 – 32 KDC số 5 Nguyễn Tri Phương (60 Nguyễn Đăng Đạo), P.Hòa Cường Bắc, Q.Hải Châu, TP. Đà Nẵng','0975288111'),
('NCC0000005',N'Đại lý cà phê',N'30 Lê Độ, Chính Gián, Thanh Khê, Đà Nẵng','0906482984')

insert into HANGHOA (MaHH, TenHH, DonViTinhHH, DonGiaHH)
values
('MHH001',N'Cam',N'ký', 30000),
('MHH002',N'Cà phê Trung Nguyên',N'gói',39000),
('MHH003',N'Ổi Hồng',N'ký', 30000),
('MHH004',N'Chanh dây',N'ký', 45000),
('MHH005',N'Chanh',N'ký', 29000),
('MHH006',N'Kem Vinamilk Socola 1L',N'hộp', 64680),
('MHH007',N'Kem Vinamilk Dâu 1L',N'hộp', 64680),
('MHH008',N'Kem Vinamilk Dừa 1L',N'hộp', 64680),
('MHH009',N'Dâu',N'ký', 100000),
('MHH010',N'Bột Matcha',N'gói',134600),
('MHH011',N'Bột Socola',N'gói',123750),
('MHH012',N'Trà Gừng',N'hộp', 26900),
('MHH013',N'Sữa Rich',N'hộp', 34500),
('MHH014',N'Sữa Topping Ice-Hot',N'hộp', 45600),
('MHH015',N'Cà phê Hồng Ân',N'gói', 34500),
('MHH016',N'Cà phê rang xay hạt',N'gói',42200),
('MHH017',N'Mứt tắc ',N'chai', 32500),
('MHH018',N'Bột Kem Béo TV HT35 Luave 1kg',N'gói', 112389),
('MHH019',N'Nước tinh khiết Aquafina 500ML*24CH',N'chai nhựa', 104963),
('MHH020',N'Bia Tiger Crystal 330ML*24Lon',N'thùng', 25500),
('MHH021',N'SỮA TƯƠI TIỆT TRÙNG VINAMILK 1L*12hộp',N'thùng',409000),
('MHH022',N'Creamer đặc Ngôi Sao Phương Nam xanh lá 1284g*12hộp',N'thùng',777418),
('MHH023',N'NƯỚC CỐT DỪA WONDERFARM 400ML',N'lon', 37000),
('MHH024',N'Thơm',N'ký', 32000),
('MHH025',N'Cà rốt',N'ký', 33500),
('MHH026',N'Bơ',N'ký', 34000),
('MHH027',N'Trà đen Phúc Long 500g',N'gói', 130000),
('MHH028',N'Trân châu ngọc trai trắng giòn 3Q BIBI JELLY 2kg',N'bịch', 56700),
('MHH029',N'Trân Châu 3Q Đen Sea Jelly Minh Hạnh 2Kg',N'bịch', 57000),
('MHH030',N'Nha đam Xuân Thịnh 2Kg',N'bịch', 40000),
('MHH031',N'Đào Ngâm Thái Lan Boddob 820gr',N'hộp',35150),
('MHH032',N'Sinh tố đào Berino 1L',N'chai', 107000),
('MHH033',N'Nước ngọt có ga Coca Cola 320ml*24lon', N'thùng',215000),
('MHH034',N'REDBULL BÒ HÚC VIỆT 250ML*24lon',N'thùng',250000)

insert into MON(TenMon, GiaTien)
values
	(N'Cà phê đen',29000),
	(N'Cà phê sữa phin',32000),
	(N'Cà phê đen Sài Gòn',30000),
	(N'Cà phê sữa Sài Gòn',35000),
	(N'Bạc xỉu',35000),
	(N'Cà phê dừa',45000),
	(N'Cà phê muối',40000),
	(N'Cà phê kem',45000),
	(N'Cà phê đen xay',30000),
	(N'Cà phê sữa xay',35000),
	(N'Americano coffee',35000),
	(N'Latte coffee',40000),
	(N'Matcha đá xay',53000),
	(N'Dâu đá xay',53000),
	(N'Socola đá xay',53000),
	(N'Chanh Tuyết',53000),
	(N'Chanh ép',43000),
	(N'Cam ép',45000),
	(N'Chanh xí muội',45000),
	(N'Cà rốt/Thơm ép',45000),
	(N'Chanh dây ổi hồng',45000),
	(N'Trà đào cam sả',50000),
	(N'Trà vải nha đam',50000),
	(N'Trà dâu nha đam',50000),
	(N'Sinh tố Amazon',55000),
	(N'Sinh tố Xoài',45000),
	(N'Sinh tố Bơ',45000),
	(N'Sinh tố Cà rốt',45000),
	(N'Trà sữa Olong',45000),
	(N'Sữa tươi chân trâu đường đen',50000),
	(N'Sữa chua Dâu',50000),
	(N'Sữa chua Cà rốt',45000),
	(N'Sữa chua Dứa',45000),
	(N'Sữa chua Đá xay',45000),
	(N'Sữa chua Vải/Nha đam',45000),
	(N'Socola nóng',45000),
	(N'Bạc Xỉu Nóng',40000),
	(N'Trà Quế Tắc Mật Ong Nóng/Đá',45000),
	(N'Trà gừng nóng',40000),
	(N'Trà Đào Xí Muội Nóng/Đá',45000),
	(N'Trà Cam Quế',45000),
	(N'Kem [Socola, Dừa, Dâu]',49000),
	(N'Nước suối',25000),
	(N'Coca',30000),
	(N'Bia',35000),
	(N'Bò húc',30000)

insert into NHANVIEN(MaNV, TenNV)
values
('NV001','Admin')

insert into BAN(MaBan,SoBan)
values
	('B.01',1),
	('B.02',2),
	('B.03',3),
	('B.04',4),
	('B.05',5),
	('B.06',6),
	('B.07',7),
	('B.08',8),
	('B.09',9),
	('B.10',10),
	('B.11',11),
	('B.12',12),
	('B.13',13),
	('B.14',14),
	('B.15',15),
	('B.16',16),
	('B.17',17),
	('B.18',18),
	('B.19',19),
	('B.20',20),
	('B.21',21),
	('B.22',22),
	('B.23',23),
	('B.24',24),
	('B.25',25),
	('B.26',26),
	('B.27',27),
	('B.28',28),
	('B.29',29),
	('B.30',30),
	('B.31',31),
	('B.32',32),
	('B.33',33),
	('B.34',34),
	('B.35',35),
	('B.36',36),
	('B.37',37),
	('B.38',38),
	('B.39',39),
	('B.40',40)


insert into KHACHHANG (MaKH, TenKH)
values
('K0001',N'Mai Thị Tuyết Trâm'),
('K0002',N'Mai Thị Hoàng Diễm'),
('K0003',N'Cẩm Trâm'),
('K0004',N'Hoàng Yến'),
('K0005',N'Tuyết Nhi'),
('K0006',N'Huỳnh Anh'),
('K0007',N'Mạnh Hùng'),
('K0008',N'Ngọc Mai'),
('K0009',N'Huy Hoàng'),
('K0010',N'Bảo Bình'),
('K0011',N'Ngọc Hoa'),
('K0012',N'Đăng Vỹ'),
('K0013',N'Huỳnh Phước Hoàng'),
('K0014',N'Nguyễn Quang Hòa'),
('K0015',N'Phan Minh Vinh'),
('K0016',N'Trần Đình Ngọc Quý'),
('K0017',N'Thục Nương'),
('K0018',N'Đoàn Hải Trân'),
('K0019',N'Nguyễn Như Đức Mạnh'),
('K0020',N'Thanh Ngọc'),
('K0021',N'Lê Vũ'),
('K0022',N'Ngọc Hải'),
('K0023',N'Xuân Trường'),
('K0024',N'Hoàng Hà'),
('K0025',N'Đinh Ngọc Trâm'),
('K0026',N'Phan Thị Ngọc Tuyền'),
('K0027',N'Ngô Mạnh Toàn'),
('K0028',N'Hoàng Thị Kim Phương'),
('K0029',N'Đỗ Mạnh Toàn'),
('K0030',N'Huy Phước '),
('K0031',N'Đinh Diệp'),
('K0032',N'Lê Mai')

 insert into MUA (MaDatHang, MaNCC, MaNV, NgayMuaHang)
values
('DH00000001','NCC0000001', 'NV001', '10-21-2023'),
('DH00000002','NCC0000001', 'NV001', '11-11-2023'),
('DH00000003','NCC0000003', 'NV001', '11-11-2023'),
('DH00000004','NCC0000002', 'NV001', '11-13-2023'),
('DH00000005','NCC0000001', 'NV001', '11-11-2023'),
('DH00000006','NCC0000001', 'NV001', '11-15-2023'),
('DH00000007','NCC0000001', 'NV001', '11-17-2023'),
('DH00000008','NCC0000003', 'NV001', '11-20-2023'),
('DH00000009','NCC0000003', 'NV001', '11-22-2023'),
('DH00000010','NCC0000003', 'NV001', '11-24-2023'),
('DH00000011','NCC0000004', 'NV001', '11-25-2023'),
('DH00000012','NCC0000005', 'NV001', '11-25-2023')

insert into MUA_CHI_TIET (MaDatHang,MaHH,SoLuongHH)
values
('DH00000001','MHH006',2),
('DH00000001','MHH007',2),
('DH00000001','MHH008',2),
('DH00000008','MHH001',2),
('DH00000008','MHH003',2),
('DH00000008','MHH004',10),
('DH00000008','MHH005',2),
('DH00000008','MHH024',2),
('DH00000008','MHH025',2),
('DH00000007','MHH010',1),
('DH00000007','MHH011',1),
('DH00000007','MHH012',1),
('DH00000007','MHH013',7),
('DH00000007','MHH014',4),
('DH00000007','MHH017',1),
('DH00000007','MHH018',1),
('DH00000007','MHH019',1),
('DH00000007','MHH020',1),
('DH00000007','MHH021',1),
('DH00000007','MHH022',1),
('DH00000007','MHH023',3),
('DH00000007','MHH027',1),
('DH00000007','MHH028',1),
('DH00000007','MHH029',1),
('DH00000007','MHH030',1),
('DH00000007','MHH031',3),
('DH00000012','MHH002',20),
('DH00000012','MHH015',20),
('DH00000012','MHH016',20)

--
insert into MUA_CHI_TIET (MaDatHang,MaHH,SoLuongHH)
values
('DH00000002','MHH032',3),
('DH00000002','MHH033',2),
('DH00000003','MHH026',2),
--('DH00000004','MHH032',3),
('DH00000005','MHH033',2),
('DH00000006','MHH034',2),
('DH00000009','MHH025',5),
('DH00000010','MHH024',6),
('DH00000011','MHH002',10),
('DH00000011','MHH015',10)
select * from MUA
select * from MUA_CHI_TIET
select * from HANGHOA
select * from NHACUNGCAP

--
insert into THANH_TOAN_HD(	MaHoaDon,MaBan,GioVao,GioRa,MaKH,MaNV)
values
('HD00000000001','B.05','11-04-2003 07:00','11-04-2003 07:30','K0001','NV001'),
('HD00000000002','B.06','11-04-2003 07:38','11-04-2003 08:00','K0003','NV001'),
('HD00000000003','B.07','11-04-2003 07:50','11-04-2003 08:20','K0004','NV001'),
('HD00000000004','B.08','11-04-2003 08:05','11-04-2003 12:30','K0006','NV001'),
('HD00000000005','B.09','11-04-2003 08:38','11-04-2003 12:00','K0011','NV001'),
('HD00000000006','B.10','11-04-2003 08:55','11-04-2003 11:10','K0012','NV001'),
('HD00000000007','B.11','11-04-2003 09:11','11-04-2003 10:58','K0005','NV001'),
('HD00000000008','B.01','11-04-2003 09:33','11-04-2003 12:47','K0007','NV001'),
('HD00000000009','B.02','11-04-2003 10:05','11-04-2003 11:59','K0008','NV001'),
('HD00000000010','B.04','11-04-2003 10:38','11-04-2003 12:38','K0009','NV001'),
('HD00000000011','B.09','11-04-2003 11:00','11-04-2003 14:30','K0010','NV001'),
('HD00000000012','B.40','11-04-2003 11:28','11-04-2003 12:50','K0013','NV001'),
('HD00000000013','B.27','11-04-2003 11:35','11-04-2003 13:20','K0014','NV001'),
('HD00000000014','B.23','11-04-2003 11:45','11-04-2003 13:30','K0015','NV001'),
('HD00000000015','B.11','11-04-2003 11:59','11-04-2003 14:00','K0016','NV001'),
('HD00000000016','B.38','11-04-2003 12:19','11-04-2003 15:40','K0017','NV001'),
('HD00000000017','B.29','11-04-2003 12:25','11-04-2003 14:58','K0018','NV001'),
('HD00000000018','B.30','11-04-2003 12:55','11-04-2003 13:47','K0019','NV001'),
('HD00000000019','B.31','11-04-2003 13:25','11-04-2003 14:59','K0020','NV001'),
('HD00000000020','B.32','11-04-2003 13:47','11-04-2003 15:38','K0032','NV001')

insert into THANH_TOAN_HD_CHI_TIET(MaHoaDon,TenMon,SoLuong)	
values
('HD00000000001',N'Cà phê đen',1),
('HD00000000001',N'Sinh tố Xoài',1),
('HD00000000001',N'Sữa chua Dâu',1),
('HD00000000001',N'Americano coffee',1),
('HD00000000002',N'Cà phê đen xay',1),
('HD00000000002',N'Sinh tố Bơ',2),
('HD00000000003',N'Sữa chua Dâu',1),
('HD00000000003',N'Americano coffee',1),
('HD00000000003',N'Trà đào cam sả',2),
('HD00000000003',N'Bạc xỉu',2),
('HD00000000004',N'Sữa chua Dứa',1),
('HD00000000004',N'Latte coffee',1),
('HD00000000004',N'Cà phê đen',1),
('HD00000000004',N'Coca',1),
('HD00000000004',N'Nước suối',1),
('HD00000000005',N'Cà phê đen Sài Gòn',1),
('HD00000000005',N'Cà phê sữa Sài Gòn',1),
('HD00000000006',N'Sữa chua Dâu',1),
('HD00000000006',N'Dâu đá xay',1),
('HD00000000006',N'Matcha đá xay',1),
('HD00000000007',N'Cà phê đen',3),
('HD00000000007',N'Cà phê sữa xay',2),
('HD00000000008',N'Cà phê sữa Sài Gòn',2),
('HD00000000009',N'Sinh tố Amazon',2),
('HD00000000009',N'Sinh tố Xoài',5),
('HD00000000010',N'Cà phê dừa',2),
('HD00000000011',N'Sữa chua Dâu',1),
('HD00000000011',N'Cà rốt/Thơm ép',1),
('HD00000000011',N'Chanh xí muội',1),
('HD00000000011',N'Cam ép',1),
('HD00000000011',N'Socola đá xay',1),
('HD00000000011',N'Sữa chua Đá xay',1),
('HD00000000011',N'Sữa chua Vải/Nha đam',1),
('HD00000000012',N'Chanh tuyết',2),
('HD00000000012',N'Sữa tươi chân trâu đường đen',2),
('HD00000000012',N'Trà sữa Olong',1),
('HD00000000013',N'Kem [Socola, Dừa, Dâu]',5),
('HD00000000014',N'Chanh dây ổi hồng',1),
('HD00000000014',N'Chanh ép',1),
('HD00000000014',N'Chanh xí muội',1),
('HD00000000015',N'Cà phê sữa phin',1),
('HD00000000016',N'Trà dâu nha đam',1),
('HD00000000017',N'Trà vải nha đam',1),
('HD00000000018',N'Cà phê sữa phin',1),
('HD00000000019',N'Cà phê kem',1),
('HD00000000019',N'Cà phê sữa Sài Gòn',1),
('HD00000000020',N'Sinh tố Cà rốt',2)

drop database Quanlycaphe

---- MUA_CHI_TIET
create trigger tTinh_ThanhTienHH
on MUA_CHI_TIET
after update 
as
begin
	declare @mahh varchar(6)
	declare @dongia numeric(15,0)
	set @dongia = (select DonGiaHH from HANGHOA where MaHH=@mahh)
	update MUA_CHI_TIET
	set ThanhTienHH= @dongia*SoLuongHH
	where MaHH=@mahh
end
update MUA_CHI_TIET set ThanhTienHH=(select DonGiaHH from HANGHOA where MaHH='MHH015')*SoLuongHH
					where MaHH='MHH015'

select * from MUA_CHI_TIET

select * from HANGHOA

----- MUA
create trigger tTinh_TongTienHH
on MUA
after update 
as
begin
	declare @madathang varchar(10)
	update MUA
	set TongTienHH= (select sum(ThanhTienHH) from MUA_CHI_TIET where MaDatHang=@madathang)
	where MaDatHang=@madathang
end
update MUA
	set TongTienHH= (select sum(ThanhTienHH) from MUA_CHI_TIET where MaDatHang='DH00000009')
	where MaDatHang='DH00000009'
update MUA
	set TongTienHH= (select sum(ThanhTienHH) from MUA_CHI_TIET where MaDatHang='DH00000011')
	where MaDatHang='DH00000011'
select * from MUA
select * from MUA_CHI_TIET

--------THANH_TOAN_HD_CHI_TIET
create trigger tTinh_ThanhTien
on THANH_TOAN_HD_CHI_TIET
after update 
as
begin
	declare @tenmon nvarchar(50)
	declare @giatien numeric(15,0)
	set @giatien = (select GiaTien from MON where TenMon=@tenmon)
	update THANH_TOAN_HD_CHI_TIET
	set ThanhTien= @giatien*SoLuong
	where TenMon=@tenmon
end
update THANH_TOAN_HD_CHI_TIET set ThanhTien=(select GiaTien from MON where TenMon=N'Trà dâu nha đam')*SoLuong
					where TenMon=N'Trà dâu nha đam'
select * from THANH_TOAN_HD_CHI_TIET
select * from MON

---- THANH_TOAN_HD
create trigger tTinh_TongTien
on THANH_TOAN_HD
after update 
as
begin
	declare @mahd varchar(13)
	update THANH_TOAN_HD
	set TongTien= (select sum(ThanhTien) from THANH_TOAN_HD_CHI_TIET where MaHoaDon=@mahd)
	where MaHoaDon=@mahd
end
update THANH_TOAN_HD
	set TongTien= (select sum(ThanhTien) from THANH_TOAN_HD_CHI_TIET where MaHoaDon='HD00000000020')
	where MaHoaDon='HD00000000020'
select * from THANH_TOAN_HD
select * from THANH_TOAN_HD_CHI_TIET

go
create proc USP_GetTableList
as select *from dbo.BAN

exec USP_GetTableList


create clustered index IX_HANGHOA_MaHH
on HANGHOA (MaHH)
select * from MUA_CHI_TIET

select * from THANH_TOAN_HD,THANH_TOAN_HD_CHI_TIET,MUA,MUA_CHI_TIET
