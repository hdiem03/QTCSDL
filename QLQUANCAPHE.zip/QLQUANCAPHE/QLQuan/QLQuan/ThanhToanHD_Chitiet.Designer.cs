﻿
namespace QLQuan
{
    partial class ThanhToanHD_Chitiet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Bang_Hoa_Don = new System.Windows.Forms.Label();
            this.fmahd = new System.Windows.Forms.Label();
            this.fFoodName = new System.Windows.Forms.Label();
            this.fSL = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(195, 60);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(228, 17);
            this.label15.TabIndex = 53;
            this.label15.Text = "--------------------------------------------";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(242, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(124, 17);
            this.label14.TabIndex = 52;
            this.label14.Text = "SĐT: 0978788799";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 17);
            this.label2.TabIndex = 51;
            this.label2.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(273, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 17);
            this.label1.TabIndex = 50;
            this.label1.Text = "DNG";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(39, 154);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(588, 237);
            this.panel1.TabIndex = 54;
            // 
            // Bang_Hoa_Don
            // 
            this.Bang_Hoa_Don.AutoSize = true;
            this.Bang_Hoa_Don.BackColor = System.Drawing.SystemColors.Control;
            this.Bang_Hoa_Don.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bang_Hoa_Don.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Bang_Hoa_Don.Location = new System.Drawing.Point(12, 77);
            this.Bang_Hoa_Don.Name = "Bang_Hoa_Don";
            this.Bang_Hoa_Don.Size = new System.Drawing.Size(642, 44);
            this.Bang_Hoa_Don.TabIndex = 55;
            this.Bang_Hoa_Don.Text = "HÓA ĐƠN THANH TOÁN CHI TIẾT";
            this.Bang_Hoa_Don.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Bang_Hoa_Don.Click += new System.EventHandler(this.Bang_Hoa_Don_Click);
            // 
            // fmahd
            // 
            this.fmahd.AutoSize = true;
            this.fmahd.Location = new System.Drawing.Point(3, 0);
            this.fmahd.Name = "fmahd";
            this.fmahd.Size = new System.Drawing.Size(83, 17);
            this.fmahd.TabIndex = 0;
            this.fmahd.Text = "Mã hóa đơn";
            this.fmahd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fFoodName
            // 
            this.fFoodName.AutoSize = true;
            this.fFoodName.Location = new System.Drawing.Point(3, 30);
            this.fFoodName.Name = "fFoodName";
            this.fFoodName.Size = new System.Drawing.Size(68, 17);
            this.fFoodName.TabIndex = 1;
            this.fFoodName.Text = "Tên món:";
            // 
            // fSL
            // 
            this.fSL.AutoSize = true;
            this.fSL.Location = new System.Drawing.Point(3, 75);
            this.fSL.Name = "fSL";
            this.fSL.Size = new System.Drawing.Size(68, 17);
            this.fSL.TabIndex = 2;
            this.fSL.Text = "Số lượng:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Thành tiền:";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.fmahd, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.fFoodName, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.fSL, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(30, 30);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.25974F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 59.74026F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(555, 144);
            this.tableLayoutPanel1.TabIndex = 56;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // ThanhToanHD_Chitiet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 491);
            this.Controls.Add(this.Bang_Hoa_Don);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ThanhToanHD_Chitiet";
            this.Text = "ThanhToanHD_Chitiet";
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Bang_Hoa_Don;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label fSL;
        private System.Windows.Forms.Label fmahd;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label fFoodName;
    }
}