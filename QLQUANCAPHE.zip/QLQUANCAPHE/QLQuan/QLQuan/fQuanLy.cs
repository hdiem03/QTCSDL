﻿
using QLQuan.DAO;
using QLQuan.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Menu = QLQuan.DTO.Menu;

namespace QLQuan
{
    public partial class fQuanLy : Form
    {
        public fQuanLy()
        {
            InitializeComponent();
            LoadTable();
            
        }
        #region Method
        void LoadTable()
        {
            List<Table> tableList = TableDAO.Instance.LoadTableList();
            foreach (Table item in tableList)
            {
                Button btn = new Button() { Width = TableDAO.TableWildth, Height = TableDAO.TableHeight };
                btn.Text = item.MaBan + Environment.NewLine + item.SoBan + Environment.NewLine +item.TinhTrang;
                switch (item.TinhTrang)
                {
                    case " Trống":
                        btn.BackColor = Color.White;
                        break;
                    default:
                        btn.BackColor = Color.LightGreen;
                        break;

                }
                btn.Click += btn_Click1;
                btn.Tag = item;
                flpTable.Controls.Add(btn);


            }
        }
        void ShowBill1(int soban)
        {
            lsbBill.Items.Clear();
            List<BillInfo1> listbillInfo1 = BillInfo1DAO.Instance.GetListBillInfo1(Bill1DAO.Instance.GetBillSoBanByTableSoBan1(soban));
            foreach (BillInfo1 item1 in listbillInfo1)
            {

                ListViewItem lsvItem1 = new ListViewItem(item1.MaHoaDon.ToString());
                lsvItem1.SubItems.Add(item1.TenMon.ToString());
                lsvItem1.SubItems.Add(item1.SoLuong.ToString());
                lsvItem1.SubItems.Add(item1.ThanhTien.ToString());
                lsbBill.Items.Add(lsvItem1);
            }
        }




        #endregion
        #region Events
        void btn_Click1(object sender, EventArgs e)
        {
            int soban = ((sender as Button).Tag as Table).SoBan;
            ShowBill1(soban);
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thôngTinCáNhânToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAccountProfile f = new fAccountProfile();
            f.ShowDialog();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void bánToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAdmin f = new fAdmin();
            f.ShowDialog();
        }
        #endregion

        private void flpTable_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flTableQLyBan_Paint(object sender, PaintEventArgs e)
        {

        }


    }
}
