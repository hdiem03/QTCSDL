﻿
namespace QL_BANHANG_AMAZON
{
    partial class FAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FAdmin));
            this.tcBill = new System.Windows.Forms.TabControl();
            this.tpFood = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridViewShowMon = new System.Windows.Forms.DataGridView();
            this.listView1 = new System.Windows.Forms.ListView();
            this.numericUpDownDonGia1 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridViewMon = new System.Windows.Forms.DataGridView();
            this.labelGiaTien = new System.Windows.Forms.Label();
            this.textBoxTenMon1 = new System.Windows.Forms.TextBox();
            this.labelTenMon1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.buttonXemMon = new System.Windows.Forms.Button();
            this.buttonSuaMon = new System.Windows.Forms.Button();
            this.buttonXoaMon = new System.Windows.Forms.Button();
            this.buttonThemMon = new System.Windows.Forms.Button();
            this.numericUpDownDonGia = new System.Windows.Forms.NumericUpDown();
            this.textBoxDVTHH = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxMaHH = new System.Windows.Forms.TextBox();
            this.textBoxTenHH = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.tbCategory = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.labelNhayDup = new System.Windows.Forms.Label();
            this.groupBoxThongTinChung = new System.Windows.Forms.GroupBox();
            this.cboMaNV = new System.Windows.Forms.ComboBox();
            this.ComboMaNV = new System.Windows.Forms.TextBox();
            this.labelMaNV = new System.Windows.Forms.Label();
            this.ComboMaKH = new System.Windows.Forms.TextBox();
            this.labelMaKH = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelNV = new System.Windows.Forms.Label();
            this.labelGioVao = new System.Windows.Forms.Label();
            this.textBoxKH = new System.Windows.Forms.TextBox();
            this.labelGioRa = new System.Windows.Forms.Label();
            this.labelMaKhachHang = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerGioVao = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.textBoxTongTien = new System.Windows.Forms.TextBox();
            this.labelTongTien = new System.Windows.Forms.Label();
            this.buttonLuu = new System.Windows.Forms.Button();
            this.buttonSua = new System.Windows.Forms.Button();
            this.buttonXoa = new System.Windows.Forms.Button();
            this.buttonThem = new System.Windows.Forms.Button();
            this.groupBoxThongTinHD = new System.Windows.Forms.GroupBox();
            this.listViewHD_ThanhToan = new System.Windows.Forms.ListView();
            this.columnHeaderMaHD = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderSoBan = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderGioVao = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderGioRa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMaKH = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderMaNV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeaderTongTien = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dgvThanhToan_HD = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.numericUpDownSoBan = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownMaHD_Thanhtoan_HD = new System.Windows.Forms.NumericUpDown();
            this.textBoxDonGia = new System.Windows.Forms.TextBox();
            this.textBoxTenMon = new System.Windows.Forms.TextBox();
            this.textBoxThanhTien = new System.Windows.Forms.TextBox();
            this.cboGiamGia = new System.Windows.Forms.ComboBox();
            this.labelThanhTien = new System.Windows.Forms.Label();
            this.labelGiamGia = new System.Windows.Forms.Label();
            this.labelDonGia = new System.Windows.Forms.Label();
            this.labelSoBan = new System.Windows.Forms.Label();
            this.labelTenMon = new System.Windows.Forms.Label();
            this.labelMaHD = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.buttonTimKiemMaHD = new System.Windows.Forms.Button();
            this.cboMaHD = new System.Windows.Forms.ComboBox();
            this.labelMaHD_TimKiem = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Bang_Hoa_Don = new System.Windows.Forms.Label();
            this.tbBan = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.nmFoodCount = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.cbFood = new System.Windows.Forms.ComboBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.cbSwitchTable = new System.Windows.Forms.NumericUpDown();
            this.btnSwitchTable = new System.Windows.Forms.Button();
            this.nmDiscount = new System.Windows.Forms.NumericUpDown();
            this.btnDiscount = new System.Windows.Forms.Button();
            this.btnCheckOut = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.lsbBill = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnlTable = new System.Windows.Forms.Panel();
            this.flpTable = new System.Windows.Forms.FlowLayoutPanel();
            this.flTableQLyBan = new System.Windows.Forms.FlowLayoutPanel();
            this.label26 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txbThanhToan_HD_chitiet = new System.Windows.Forms.TabPage();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.lbThanhTien = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.lbSoBan = new System.Windows.Forms.Label();
            this.tbMaHH = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tcBill.SuspendLayout();
            this.tpFood.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowMon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDonGia1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMon)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDonGia)).BeginInit();
            this.tbCategory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBoxThongTinChung.SuspendLayout();
            this.panel9.SuspendLayout();
            this.groupBoxThongTinHD.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThanhToan_HD)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSoBan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMaHD_Thanhtoan_HD)).BeginInit();
            this.panel12.SuspendLayout();
            this.tbBan.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmFoodCount)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cbSwitchTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmDiscount)).BeginInit();
            this.panel14.SuspendLayout();
            this.pnlTable.SuspendLayout();
            this.flpTable.SuspendLayout();
            this.txbThanhToan_HD_chitiet.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.panel20.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcBill
            // 
            this.tcBill.Controls.Add(this.tpFood);
            this.tcBill.Controls.Add(this.tbCategory);
            this.tcBill.Controls.Add(this.tbBan);
            this.tcBill.Controls.Add(this.txbThanhToan_HD_chitiet);
            this.tcBill.Location = new System.Drawing.Point(2, 1);
            this.tcBill.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tcBill.Name = "tcBill";
            this.tcBill.SelectedIndex = 0;
            this.tcBill.Size = new System.Drawing.Size(838, 972);
            this.tcBill.TabIndex = 1;
            // 
            // tpFood
            // 
            this.tpFood.Controls.Add(this.panel3);
            this.tpFood.Controls.Add(this.panel4);
            this.tpFood.Controls.Add(this.numericUpDownDonGia);
            this.tpFood.Controls.Add(this.textBoxDVTHH);
            this.tpFood.Controls.Add(this.label19);
            this.tpFood.Controls.Add(this.label20);
            this.tpFood.Controls.Add(this.label2);
            this.tpFood.Controls.Add(this.textBoxMaHH);
            this.tpFood.Controls.Add(this.textBoxTenHH);
            this.tpFood.Controls.Add(this.label3);
            this.tpFood.Controls.Add(this.label27);
            this.tpFood.Controls.Add(this.label28);
            this.tpFood.Controls.Add(this.label29);
            this.tpFood.Controls.Add(this.label30);
            this.tpFood.Controls.Add(this.label31);
            this.tpFood.Location = new System.Drawing.Point(4, 29);
            this.tpFood.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tpFood.Name = "tpFood";
            this.tpFood.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tpFood.Size = new System.Drawing.Size(830, 939);
            this.tpFood.TabIndex = 1;
            this.tpFood.Text = "Món";
            this.tpFood.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dataGridViewShowMon);
            this.panel3.Controls.Add(this.listView1);
            this.panel3.Controls.Add(this.numericUpDownDonGia1);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.dataGridViewMon);
            this.panel3.Controls.Add(this.labelGiaTien);
            this.panel3.Controls.Add(this.textBoxTenMon1);
            this.panel3.Controls.Add(this.labelTenMon1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 4);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(824, 866);
            this.panel3.TabIndex = 79;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // dataGridViewShowMon
            // 
            this.dataGridViewShowMon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShowMon.Location = new System.Drawing.Point(-3, 388);
            this.dataGridViewShowMon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewShowMon.Name = "dataGridViewShowMon";
            this.dataGridViewShowMon.RowHeadersWidth = 51;
            this.dataGridViewShowMon.RowTemplate.Height = 24;
            this.dataGridViewShowMon.Size = new System.Drawing.Size(826, 476);
            this.dataGridViewShowMon.TabIndex = 88;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(-3, 388);
            this.listView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(825, 475);
            this.listView1.TabIndex = 87;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // numericUpDownDonGia1
            // 
            this.numericUpDownDonGia1.Location = new System.Drawing.Point(362, 331);
            this.numericUpDownDonGia1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDownDonGia1.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDownDonGia1.Name = "numericUpDownDonGia1";
            this.numericUpDownDonGia1.Size = new System.Drawing.Size(169, 26);
            this.numericUpDownDonGia1.TabIndex = 86;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label5.Location = new System.Drawing.Point(303, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 65);
            this.label5.TabIndex = 85;
            this.label5.Text = "MÓN";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(252, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(229, 20);
            this.label8.TabIndex = 84;
            this.label8.Text = "--------------------------------------------";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(305, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 20);
            this.label9.TabIndex = 83;
            this.label9.Text = "SĐT: 0978788799";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(266, 38);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(232, 20);
            this.label10.TabIndex = 82;
            this.label10.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(340, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 20);
            this.label11.TabIndex = 81;
            this.label11.Text = "DNG";
            // 
            // dataGridViewMon
            // 
            this.dataGridViewMon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMon.Location = new System.Drawing.Point(0, 388);
            this.dataGridViewMon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewMon.Name = "dataGridViewMon";
            this.dataGridViewMon.RowHeadersWidth = 51;
            this.dataGridViewMon.RowTemplate.Height = 24;
            this.dataGridViewMon.Size = new System.Drawing.Size(822, 476);
            this.dataGridViewMon.TabIndex = 80;
            // 
            // labelGiaTien
            // 
            this.labelGiaTien.AutoSize = true;
            this.labelGiaTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelGiaTien.Location = new System.Drawing.Point(174, 331);
            this.labelGiaTien.Name = "labelGiaTien";
            this.labelGiaTien.Size = new System.Drawing.Size(122, 32);
            this.labelGiaTien.TabIndex = 10;
            this.labelGiaTien.Text = "Giá tiền:";
            // 
            // textBoxTenMon1
            // 
            this.textBoxTenMon1.Location = new System.Drawing.Point(362, 268);
            this.textBoxTenMon1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxTenMon1.Name = "textBoxTenMon1";
            this.textBoxTenMon1.Size = new System.Drawing.Size(168, 26);
            this.textBoxTenMon1.TabIndex = 0;
            // 
            // labelTenMon1
            // 
            this.labelTenMon1.AutoSize = true;
            this.labelTenMon1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTenMon1.Location = new System.Drawing.Point(160, 268);
            this.labelTenMon1.Name = "labelTenMon1";
            this.labelTenMon1.Size = new System.Drawing.Size(134, 32);
            this.labelTenMon1.TabIndex = 2;
            this.labelTenMon1.Text = "Tên món:";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.buttonXemMon);
            this.panel4.Controls.Add(this.buttonSuaMon);
            this.panel4.Controls.Add(this.buttonXoaMon);
            this.panel4.Controls.Add(this.buttonThemMon);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(3, 870);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(824, 65);
            this.panel4.TabIndex = 81;
            // 
            // buttonXemMon
            // 
            this.buttonXemMon.Location = new System.Drawing.Point(626, 4);
            this.buttonXemMon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonXemMon.Name = "buttonXemMon";
            this.buttonXemMon.Size = new System.Drawing.Size(89, 54);
            this.buttonXemMon.TabIndex = 7;
            this.buttonXemMon.Text = "Xem";
            this.buttonXemMon.UseVisualStyleBackColor = true;
            // 
            // buttonSuaMon
            // 
            this.buttonSuaMon.Location = new System.Drawing.Point(431, 8);
            this.buttonSuaMon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonSuaMon.Name = "buttonSuaMon";
            this.buttonSuaMon.Size = new System.Drawing.Size(89, 54);
            this.buttonSuaMon.TabIndex = 6;
            this.buttonSuaMon.Text = "Sửa";
            this.buttonSuaMon.UseVisualStyleBackColor = true;
            this.buttonSuaMon.Click += new System.EventHandler(this.buttonSuaMon_Click);
            // 
            // buttonXoaMon
            // 
            this.buttonXoaMon.Location = new System.Drawing.Point(241, 8);
            this.buttonXoaMon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonXoaMon.Name = "buttonXoaMon";
            this.buttonXoaMon.Size = new System.Drawing.Size(89, 54);
            this.buttonXoaMon.TabIndex = 5;
            this.buttonXoaMon.Text = "Xóa";
            this.buttonXoaMon.UseVisualStyleBackColor = true;
            this.buttonXoaMon.Click += new System.EventHandler(this.buttonXoaMon_Click);
            // 
            // buttonThemMon
            // 
            this.buttonThemMon.Location = new System.Drawing.Point(37, 8);
            this.buttonThemMon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonThemMon.Name = "buttonThemMon";
            this.buttonThemMon.Size = new System.Drawing.Size(89, 54);
            this.buttonThemMon.TabIndex = 4;
            this.buttonThemMon.Text = "Thêm";
            this.buttonThemMon.UseVisualStyleBackColor = true;
            this.buttonThemMon.Click += new System.EventHandler(this.buttonThemMon_Click);
            // 
            // numericUpDownDonGia
            // 
            this.numericUpDownDonGia.Location = new System.Drawing.Point(629, 304);
            this.numericUpDownDonGia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDownDonGia.Name = "numericUpDownDonGia";
            this.numericUpDownDonGia.Size = new System.Drawing.Size(144, 26);
            this.numericUpDownDonGia.TabIndex = 78;
            // 
            // textBoxDVTHH
            // 
            this.textBoxDVTHH.Location = new System.Drawing.Point(629, 248);
            this.textBoxDVTHH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxDVTHH.Name = "textBoxDVTHH";
            this.textBoxDVTHH.Size = new System.Drawing.Size(144, 26);
            this.textBoxDVTHH.TabIndex = 75;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(484, 302);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 20);
            this.label19.TabIndex = 77;
            this.label19.Text = "Đơn giá:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(484, 254);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(87, 20);
            this.label20.TabIndex = 76;
            this.label20.Text = "Đơn vị tính:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 20);
            this.label2.TabIndex = 74;
            this.label2.Text = "Mã hàng hóa:";
            // 
            // textBoxMaHH
            // 
            this.textBoxMaHH.Location = new System.Drawing.Point(144, 248);
            this.textBoxMaHH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxMaHH.Name = "textBoxMaHH";
            this.textBoxMaHH.Size = new System.Drawing.Size(147, 26);
            this.textBoxMaHH.TabIndex = 71;
            // 
            // textBoxTenHH
            // 
            this.textBoxTenHH.Location = new System.Drawing.Point(144, 296);
            this.textBoxTenHH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxTenHH.Name = "textBoxTenHH";
            this.textBoxTenHH.Size = new System.Drawing.Size(147, 26);
            this.textBoxTenHH.TabIndex = 72;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 304);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 20);
            this.label3.TabIndex = 73;
            this.label3.Text = "Tên hàng hóa:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(278, 84);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(229, 20);
            this.label27.TabIndex = 70;
            this.label27.Text = "--------------------------------------------";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(331, 62);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(139, 20);
            this.label28.TabIndex = 69;
            this.label28.Text = "SĐT: 0978788799";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(291, 41);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(232, 20);
            this.label29.TabIndex = 68;
            this.label29.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(366, 20);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(45, 20);
            this.label30.TabIndex = 67;
            this.label30.Text = "DNG";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.Control;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label31.Location = new System.Drawing.Point(314, 139);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(163, 65);
            this.label31.TabIndex = 66;
            this.label31.Text = "MÓN";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tbCategory
            // 
            this.tbCategory.Controls.Add(this.splitContainer1);
            this.tbCategory.Controls.Add(this.label15);
            this.tbCategory.Controls.Add(this.panel12);
            this.tbCategory.Controls.Add(this.label14);
            this.tbCategory.Controls.Add(this.label1);
            this.tbCategory.Controls.Add(this.label4);
            this.tbCategory.Controls.Add(this.Bang_Hoa_Don);
            this.tbCategory.Location = new System.Drawing.Point(4, 29);
            this.tbCategory.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbCategory.Name = "tbCategory";
            this.tbCategory.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbCategory.Size = new System.Drawing.Size(830, 939);
            this.tbCategory.TabIndex = 2;
            this.tbCategory.Text = "Thanh toán hóa đơn";
            this.tbCategory.UseVisualStyleBackColor = true;
            this.tbCategory.Click += new System.EventHandler(this.tbCategory_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(7, 146);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.labelNhayDup);
            this.splitContainer1.Panel1.Controls.Add(this.groupBoxThongTinChung);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel9);
            this.splitContainer1.Panel2.Controls.Add(this.groupBoxThongTinHD);
            this.splitContainer1.Size = new System.Drawing.Size(816, 716);
            this.splitContainer1.SplitterDistance = 271;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 54;
            // 
            // labelNhayDup
            // 
            this.labelNhayDup.AutoSize = true;
            this.labelNhayDup.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNhayDup.ForeColor = System.Drawing.Color.Red;
            this.labelNhayDup.Location = new System.Drawing.Point(17, 232);
            this.labelNhayDup.Name = "labelNhayDup";
            this.labelNhayDup.Size = new System.Drawing.Size(198, 20);
            this.labelNhayDup.TabIndex = 48;
            this.labelNhayDup.Text = "Nháy đúp một dòng để xóa";
            // 
            // groupBoxThongTinChung
            // 
            this.groupBoxThongTinChung.Controls.Add(this.cboMaNV);
            this.groupBoxThongTinChung.Controls.Add(this.ComboMaNV);
            this.groupBoxThongTinChung.Controls.Add(this.labelMaNV);
            this.groupBoxThongTinChung.Controls.Add(this.ComboMaKH);
            this.groupBoxThongTinChung.Controls.Add(this.labelMaKH);
            this.groupBoxThongTinChung.Controls.Add(this.textBox1);
            this.groupBoxThongTinChung.Controls.Add(this.labelNV);
            this.groupBoxThongTinChung.Controls.Add(this.labelGioVao);
            this.groupBoxThongTinChung.Controls.Add(this.textBoxKH);
            this.groupBoxThongTinChung.Controls.Add(this.labelGioRa);
            this.groupBoxThongTinChung.Controls.Add(this.labelMaKhachHang);
            this.groupBoxThongTinChung.Controls.Add(this.dateTimePicker3);
            this.groupBoxThongTinChung.Controls.Add(this.dateTimePickerGioVao);
            this.groupBoxThongTinChung.Controls.Add(this.label6);
            this.groupBoxThongTinChung.Location = new System.Drawing.Point(3, 10);
            this.groupBoxThongTinChung.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxThongTinChung.Name = "groupBoxThongTinChung";
            this.groupBoxThongTinChung.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxThongTinChung.Size = new System.Drawing.Size(819, 219);
            this.groupBoxThongTinChung.TabIndex = 0;
            this.groupBoxThongTinChung.TabStop = false;
            this.groupBoxThongTinChung.Text = "Thông tin chung";
            // 
            // cboMaNV
            // 
            this.cboMaNV.FormattingEnabled = true;
            this.cboMaNV.Location = new System.Drawing.Point(609, 121);
            this.cboMaNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboMaNV.Name = "cboMaNV";
            this.cboMaNV.Size = new System.Drawing.Size(149, 28);
            this.cboMaNV.TabIndex = 94;
            // 
            // ComboMaNV
            // 
            this.ComboMaNV.Location = new System.Drawing.Point(609, 171);
            this.ComboMaNV.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ComboMaNV.Name = "ComboMaNV";
            this.ComboMaNV.Size = new System.Drawing.Size(149, 26);
            this.ComboMaNV.TabIndex = 93;
            // 
            // labelMaNV
            // 
            this.labelMaNV.AutoSize = true;
            this.labelMaNV.Location = new System.Drawing.Point(475, 175);
            this.labelMaNV.Name = "labelMaNV";
            this.labelMaNV.Size = new System.Drawing.Size(111, 20);
            this.labelMaNV.TabIndex = 92;
            this.labelMaNV.Text = "Mã nhân viên: ";
            // 
            // ComboMaKH
            // 
            this.ComboMaKH.Location = new System.Drawing.Point(151, 175);
            this.ComboMaKH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ComboMaKH.Name = "ComboMaKH";
            this.ComboMaKH.Size = new System.Drawing.Size(145, 26);
            this.ComboMaKH.TabIndex = 91;
            this.ComboMaKH.TextChanged += new System.EventHandler(this.ComboMaKH_TextChanged);
            // 
            // labelMaKH
            // 
            this.labelMaKH.AutoSize = true;
            this.labelMaKH.Location = new System.Drawing.Point(14, 175);
            this.labelMaKH.Name = "labelMaKH";
            this.labelMaKH.Size = new System.Drawing.Size(126, 20);
            this.labelMaKH.TabIndex = 90;
            this.labelMaKH.Text = "Mã khách hàng: ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(372, 26);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(142, 26);
            this.textBox1.TabIndex = 84;
            // 
            // labelNV
            // 
            this.labelNV.AutoSize = true;
            this.labelNV.Location = new System.Drawing.Point(489, 122);
            this.labelNV.Name = "labelNV";
            this.labelNV.Size = new System.Drawing.Size(83, 20);
            this.labelNV.TabIndex = 83;
            this.labelNV.Text = "Nhân viên:";
            // 
            // labelGioVao
            // 
            this.labelGioVao.AutoSize = true;
            this.labelGioVao.Location = new System.Drawing.Point(68, 82);
            this.labelGioVao.Name = "labelGioVao";
            this.labelGioVao.Size = new System.Drawing.Size(67, 20);
            this.labelGioVao.TabIndex = 88;
            this.labelGioVao.Text = "Giờ vào:";
            // 
            // textBoxKH
            // 
            this.textBoxKH.Location = new System.Drawing.Point(151, 119);
            this.textBoxKH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxKH.Name = "textBoxKH";
            this.textBoxKH.Size = new System.Drawing.Size(145, 26);
            this.textBoxKH.TabIndex = 85;
            // 
            // labelGioRa
            // 
            this.labelGioRa.AutoSize = true;
            this.labelGioRa.Location = new System.Drawing.Point(518, 82);
            this.labelGioRa.Name = "labelGioRa";
            this.labelGioRa.Size = new System.Drawing.Size(56, 20);
            this.labelGioRa.TabIndex = 80;
            this.labelGioRa.Text = "Giờ ra:";
            // 
            // labelMaKhachHang
            // 
            this.labelMaKhachHang.AutoSize = true;
            this.labelMaKhachHang.Location = new System.Drawing.Point(37, 125);
            this.labelMaKhachHang.Name = "labelMaKhachHang";
            this.labelMaKhachHang.Size = new System.Drawing.Size(102, 20);
            this.labelMaKhachHang.TabIndex = 82;
            this.labelMaKhachHang.Text = "Khách hàng: ";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker3.Location = new System.Drawing.Point(609, 76);
            this.dateTimePicker3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(149, 26);
            this.dateTimePicker3.TabIndex = 87;
            // 
            // dateTimePickerGioVao
            // 
            this.dateTimePickerGioVao.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePickerGioVao.Location = new System.Drawing.Point(151, 76);
            this.dateTimePickerGioVao.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePickerGioVao.Name = "dateTimePickerGioVao";
            this.dateTimePickerGioVao.Size = new System.Drawing.Size(145, 26);
            this.dateTimePickerGioVao.TabIndex = 86;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(303, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 20);
            this.label6.TabIndex = 81;
            this.label6.Text = "Ngày:";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.textBoxTongTien);
            this.panel9.Controls.Add(this.labelTongTien);
            this.panel9.Controls.Add(this.buttonLuu);
            this.panel9.Controls.Add(this.buttonSua);
            this.panel9.Controls.Add(this.buttonXoa);
            this.panel9.Controls.Add(this.buttonThem);
            this.panel9.Location = new System.Drawing.Point(3, 371);
            this.panel9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(810, 61);
            this.panel9.TabIndex = 1;
            // 
            // textBoxTongTien
            // 
            this.textBoxTongTien.Location = new System.Drawing.Point(691, 19);
            this.textBoxTongTien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxTongTien.Name = "textBoxTongTien";
            this.textBoxTongTien.Size = new System.Drawing.Size(102, 26);
            this.textBoxTongTien.TabIndex = 48;
            // 
            // labelTongTien
            // 
            this.labelTongTien.AutoSize = true;
            this.labelTongTien.Location = new System.Drawing.Point(613, 22);
            this.labelTongTien.Name = "labelTongTien";
            this.labelTongTien.Size = new System.Drawing.Size(79, 20);
            this.labelTongTien.TabIndex = 4;
            this.labelTongTien.Text = "Tổng tiền:";
            // 
            // buttonLuu
            // 
            this.buttonLuu.Location = new System.Drawing.Point(456, 0);
            this.buttonLuu.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonLuu.Name = "buttonLuu";
            this.buttonLuu.Size = new System.Drawing.Size(89, 54);
            this.buttonLuu.TabIndex = 3;
            this.buttonLuu.Text = "Lưu";
            this.buttonLuu.UseVisualStyleBackColor = true;
            // 
            // buttonSua
            // 
            this.buttonSua.Location = new System.Drawing.Point(306, 0);
            this.buttonSua.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonSua.Name = "buttonSua";
            this.buttonSua.Size = new System.Drawing.Size(89, 54);
            this.buttonSua.TabIndex = 2;
            this.buttonSua.Text = "Sửa";
            this.buttonSua.UseVisualStyleBackColor = true;
            // 
            // buttonXoa
            // 
            this.buttonXoa.Location = new System.Drawing.Point(169, 4);
            this.buttonXoa.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonXoa.Name = "buttonXoa";
            this.buttonXoa.Size = new System.Drawing.Size(89, 54);
            this.buttonXoa.TabIndex = 1;
            this.buttonXoa.Text = "Xóa";
            this.buttonXoa.UseVisualStyleBackColor = true;
            // 
            // buttonThem
            // 
            this.buttonThem.Location = new System.Drawing.Point(18, 4);
            this.buttonThem.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonThem.Name = "buttonThem";
            this.buttonThem.Size = new System.Drawing.Size(89, 54);
            this.buttonThem.TabIndex = 0;
            this.buttonThem.Text = "Thêm";
            this.buttonThem.UseVisualStyleBackColor = true;
            this.buttonThem.Click += new System.EventHandler(this.buttonThem_Click);
            // 
            // groupBoxThongTinHD
            // 
            this.groupBoxThongTinHD.Controls.Add(this.listViewHD_ThanhToan);
            this.groupBoxThongTinHD.Controls.Add(this.dgvThanhToan_HD);
            this.groupBoxThongTinHD.Controls.Add(this.panel2);
            this.groupBoxThongTinHD.Location = new System.Drawing.Point(7, 4);
            this.groupBoxThongTinHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxThongTinHD.Name = "groupBoxThongTinHD";
            this.groupBoxThongTinHD.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxThongTinHD.Size = new System.Drawing.Size(810, 364);
            this.groupBoxThongTinHD.TabIndex = 0;
            this.groupBoxThongTinHD.TabStop = false;
            this.groupBoxThongTinHD.Text = "Thông tin hóa đơn";
            // 
            // listViewHD_ThanhToan
            // 
            this.listViewHD_ThanhToan.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderMaHD,
            this.columnHeaderSoBan,
            this.columnHeaderGioVao,
            this.columnHeaderGioRa,
            this.columnHeaderMaKH,
            this.columnHeaderMaNV,
            this.columnHeaderTongTien});
            this.listViewHD_ThanhToan.GridLines = true;
            this.listViewHD_ThanhToan.HideSelection = false;
            this.listViewHD_ThanhToan.Location = new System.Drawing.Point(4, 142);
            this.listViewHD_ThanhToan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listViewHD_ThanhToan.Name = "listViewHD_ThanhToan";
            this.listViewHD_ThanhToan.Size = new System.Drawing.Size(802, 216);
            this.listViewHD_ThanhToan.TabIndex = 2;
            this.listViewHD_ThanhToan.UseCompatibleStateImageBehavior = false;
            this.listViewHD_ThanhToan.View = System.Windows.Forms.View.Details;
            // 
            // columnHeaderMaHD
            // 
            this.columnHeaderMaHD.Text = "Mã hóa đơn";
            this.columnHeaderMaHD.Width = 110;
            // 
            // columnHeaderSoBan
            // 
            this.columnHeaderSoBan.Text = "Số Bàn";
            this.columnHeaderSoBan.Width = 99;
            // 
            // columnHeaderGioVao
            // 
            this.columnHeaderGioVao.Text = "Giờ vào";
            this.columnHeaderGioVao.Width = 91;
            // 
            // columnHeaderGioRa
            // 
            this.columnHeaderGioRa.Text = "Giờ ra";
            this.columnHeaderGioRa.Width = 88;
            // 
            // columnHeaderMaKH
            // 
            this.columnHeaderMaKH.Text = "Mã KH";
            this.columnHeaderMaKH.Width = 75;
            // 
            // columnHeaderMaNV
            // 
            this.columnHeaderMaNV.Text = "Mã NV";
            this.columnHeaderMaNV.Width = 79;
            // 
            // columnHeaderTongTien
            // 
            this.columnHeaderTongTien.Text = "Tổng tiền";
            this.columnHeaderTongTien.Width = 344;
            // 
            // dgvThanhToan_HD
            // 
            this.dgvThanhToan_HD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThanhToan_HD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThanhToan_HD.Location = new System.Drawing.Point(3, 143);
            this.dgvThanhToan_HD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvThanhToan_HD.Name = "dgvThanhToan_HD";
            this.dgvThanhToan_HD.RowHeadersWidth = 51;
            this.dgvThanhToan_HD.RowTemplate.Height = 24;
            this.dgvThanhToan_HD.Size = new System.Drawing.Size(804, 217);
            this.dgvThanhToan_HD.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.numericUpDownSoBan);
            this.panel2.Controls.Add(this.numericUpDownMaHD_Thanhtoan_HD);
            this.panel2.Controls.Add(this.textBoxDonGia);
            this.panel2.Controls.Add(this.textBoxTenMon);
            this.panel2.Controls.Add(this.textBoxThanhTien);
            this.panel2.Controls.Add(this.cboGiamGia);
            this.panel2.Controls.Add(this.labelThanhTien);
            this.panel2.Controls.Add(this.labelGiamGia);
            this.panel2.Controls.Add(this.labelDonGia);
            this.panel2.Controls.Add(this.labelSoBan);
            this.panel2.Controls.Add(this.labelTenMon);
            this.panel2.Controls.Add(this.labelMaHD);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 23);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(804, 120);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // numericUpDownSoBan
            // 
            this.numericUpDownSoBan.Location = new System.Drawing.Point(144, 50);
            this.numericUpDownSoBan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDownSoBan.Name = "numericUpDownSoBan";
            this.numericUpDownSoBan.Size = new System.Drawing.Size(133, 26);
            this.numericUpDownSoBan.TabIndex = 49;
            // 
            // numericUpDownMaHD_Thanhtoan_HD
            // 
            this.numericUpDownMaHD_Thanhtoan_HD.Location = new System.Drawing.Point(144, 14);
            this.numericUpDownMaHD_Thanhtoan_HD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDownMaHD_Thanhtoan_HD.Name = "numericUpDownMaHD_Thanhtoan_HD";
            this.numericUpDownMaHD_Thanhtoan_HD.Size = new System.Drawing.Size(133, 26);
            this.numericUpDownMaHD_Thanhtoan_HD.TabIndex = 48;
            // 
            // textBoxDonGia
            // 
            this.textBoxDonGia.Location = new System.Drawing.Point(654, 14);
            this.textBoxDonGia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxDonGia.Name = "textBoxDonGia";
            this.textBoxDonGia.Size = new System.Drawing.Size(133, 26);
            this.textBoxDonGia.TabIndex = 47;
            // 
            // textBoxTenMon
            // 
            this.textBoxTenMon.Location = new System.Drawing.Point(394, 14);
            this.textBoxTenMon.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxTenMon.Name = "textBoxTenMon";
            this.textBoxTenMon.Size = new System.Drawing.Size(133, 26);
            this.textBoxTenMon.TabIndex = 46;
            // 
            // textBoxThanhTien
            // 
            this.textBoxThanhTien.Location = new System.Drawing.Point(654, 52);
            this.textBoxThanhTien.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBoxThanhTien.Name = "textBoxThanhTien";
            this.textBoxThanhTien.Size = new System.Drawing.Size(133, 26);
            this.textBoxThanhTien.TabIndex = 44;
            // 
            // cboGiamGia
            // 
            this.cboGiamGia.FormattingEnabled = true;
            this.cboGiamGia.Location = new System.Drawing.Point(394, 50);
            this.cboGiamGia.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboGiamGia.Name = "cboGiamGia";
            this.cboGiamGia.Size = new System.Drawing.Size(133, 28);
            this.cboGiamGia.TabIndex = 43;
            // 
            // labelThanhTien
            // 
            this.labelThanhTien.AutoSize = true;
            this.labelThanhTien.Location = new System.Drawing.Point(557, 56);
            this.labelThanhTien.Name = "labelThanhTien";
            this.labelThanhTien.Size = new System.Drawing.Size(88, 20);
            this.labelThanhTien.TabIndex = 37;
            this.labelThanhTien.Text = "Thành tiền:";
            // 
            // labelGiamGia
            // 
            this.labelGiamGia.AutoSize = true;
            this.labelGiamGia.Location = new System.Drawing.Point(294, 58);
            this.labelGiamGia.Name = "labelGiamGia";
            this.labelGiamGia.Size = new System.Drawing.Size(76, 20);
            this.labelGiamGia.TabIndex = 42;
            this.labelGiamGia.Text = "Giảm giá:";
            // 
            // labelDonGia
            // 
            this.labelDonGia.AutoSize = true;
            this.labelDonGia.Location = new System.Drawing.Point(568, 24);
            this.labelDonGia.Name = "labelDonGia";
            this.labelDonGia.Size = new System.Drawing.Size(68, 20);
            this.labelDonGia.TabIndex = 40;
            this.labelDonGia.Text = "Đơn giá:";
            // 
            // labelSoBan
            // 
            this.labelSoBan.AutoSize = true;
            this.labelSoBan.Location = new System.Drawing.Point(22, 61);
            this.labelSoBan.Name = "labelSoBan";
            this.labelSoBan.Size = new System.Drawing.Size(64, 20);
            this.labelSoBan.TabIndex = 39;
            this.labelSoBan.Text = "Số bàn:";
            // 
            // labelTenMon
            // 
            this.labelTenMon.AutoSize = true;
            this.labelTenMon.Location = new System.Drawing.Point(295, 22);
            this.labelTenMon.Name = "labelTenMon";
            this.labelTenMon.Size = new System.Drawing.Size(75, 20);
            this.labelTenMon.TabIndex = 33;
            this.labelTenMon.Text = "Tên món:";
            // 
            // labelMaHD
            // 
            this.labelMaHD.AutoSize = true;
            this.labelMaHD.Location = new System.Drawing.Point(24, 24);
            this.labelMaHD.Name = "labelMaHD";
            this.labelMaHD.Size = new System.Drawing.Size(97, 20);
            this.labelMaHD.TabIndex = 34;
            this.labelMaHD.Text = "Mã hóa đơn:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(259, 62);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(229, 20);
            this.label15.TabIndex = 52;
            this.label15.Text = "--------------------------------------------";
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.buttonTimKiemMaHD);
            this.panel12.Controls.Add(this.cboMaHD);
            this.panel12.Controls.Add(this.labelMaHD_TimKiem);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel12.Location = new System.Drawing.Point(3, 881);
            this.panel12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(824, 54);
            this.panel12.TabIndex = 53;
            // 
            // buttonTimKiemMaHD
            // 
            this.buttonTimKiemMaHD.Image = ((System.Drawing.Image)(resources.GetObject("buttonTimKiemMaHD.Image")));
            this.buttonTimKiemMaHD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonTimKiemMaHD.Location = new System.Drawing.Point(345, 20);
            this.buttonTimKiemMaHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttonTimKiemMaHD.Name = "buttonTimKiemMaHD";
            this.buttonTimKiemMaHD.Size = new System.Drawing.Size(136, 29);
            this.buttonTimKiemMaHD.TabIndex = 5;
            this.buttonTimKiemMaHD.Text = "&Tìm Kiếm";
            this.buttonTimKiemMaHD.UseVisualStyleBackColor = true;
            // 
            // cboMaHD
            // 
            this.cboMaHD.FormattingEnabled = true;
            this.cboMaHD.Location = new System.Drawing.Point(134, 20);
            this.cboMaHD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cboMaHD.Name = "cboMaHD";
            this.cboMaHD.Size = new System.Drawing.Size(185, 28);
            this.cboMaHD.TabIndex = 4;
            // 
            // labelMaHD_TimKiem
            // 
            this.labelMaHD_TimKiem.AutoSize = true;
            this.labelMaHD_TimKiem.Location = new System.Drawing.Point(24, 24);
            this.labelMaHD_TimKiem.Name = "labelMaHD_TimKiem";
            this.labelMaHD_TimKiem.Size = new System.Drawing.Size(97, 20);
            this.labelMaHD_TimKiem.TabIndex = 3;
            this.labelMaHD_TimKiem.Text = "Mã hóa đơn:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(312, 41);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(139, 20);
            this.label14.TabIndex = 51;
            this.label14.Text = "SĐT: 0978788799";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(272, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(232, 20);
            this.label1.TabIndex = 50;
            this.label1.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(346, -1);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 20);
            this.label4.TabIndex = 49;
            this.label4.Text = "DNG";
            // 
            // Bang_Hoa_Don
            // 
            this.Bang_Hoa_Don.AutoSize = true;
            this.Bang_Hoa_Don.BackColor = System.Drawing.SystemColors.Control;
            this.Bang_Hoa_Don.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bang_Hoa_Don.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Bang_Hoa_Don.Location = new System.Drawing.Point(70, 74);
            this.Bang_Hoa_Don.Name = "Bang_Hoa_Don";
            this.Bang_Hoa_Don.Size = new System.Drawing.Size(694, 65);
            this.Bang_Hoa_Don.TabIndex = 48;
            this.Bang_Hoa_Don.Text = "HÓA ĐƠN THANH TOÁN";
            this.Bang_Hoa_Don.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tbBan
            // 
            this.tbBan.Controls.Add(this.panel1);
            this.tbBan.Controls.Add(this.panel13);
            this.tbBan.Controls.Add(this.panel14);
            this.tbBan.Controls.Add(this.pnlTable);
            this.tbBan.Controls.Add(this.label26);
            this.tbBan.Controls.Add(this.label21);
            this.tbBan.Controls.Add(this.label22);
            this.tbBan.Controls.Add(this.label24);
            this.tbBan.Controls.Add(this.label25);
            this.tbBan.Location = new System.Drawing.Point(4, 29);
            this.tbBan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbBan.Name = "tbBan";
            this.tbBan.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbBan.Size = new System.Drawing.Size(830, 939);
            this.tbBan.TabIndex = 3;
            this.tbBan.Text = "Bàn";
            this.tbBan.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.nmFoodCount);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.cbFood);
            this.panel1.Location = new System.Drawing.Point(420, 175);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(386, 85);
            this.panel1.TabIndex = 59;
            // 
            // nmFoodCount
            // 
            this.nmFoodCount.Location = new System.Drawing.Point(331, 25);
            this.nmFoodCount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nmFoodCount.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.nmFoodCount.Name = "nmFoodCount";
            this.nmFoodCount.Size = new System.Drawing.Size(47, 26);
            this.nmFoodCount.TabIndex = 3;
            this.nmFoodCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nmFoodCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(243, 5);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(84, 66);
            this.button1.TabIndex = 2;
            this.button1.Text = "Thêm món";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cbFood
            // 
            this.cbFood.FormattingEnabled = true;
            this.cbFood.Location = new System.Drawing.Point(7, 22);
            this.cbFood.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbFood.Name = "cbFood";
            this.cbFood.Size = new System.Drawing.Size(229, 28);
            this.cbFood.TabIndex = 0;
            this.cbFood.SelectedIndexChanged += new System.EventHandler(this.cbFood_SelectedIndexChanged);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.cbSwitchTable);
            this.panel13.Controls.Add(this.btnSwitchTable);
            this.panel13.Controls.Add(this.nmDiscount);
            this.panel13.Controls.Add(this.btnDiscount);
            this.panel13.Controls.Add(this.btnCheckOut);
            this.panel13.Location = new System.Drawing.Point(416, 756);
            this.panel13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(381, 122);
            this.panel13.TabIndex = 58;
            // 
            // cbSwitchTable
            // 
            this.cbSwitchTable.Location = new System.Drawing.Point(3, 64);
            this.cbSwitchTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbSwitchTable.Name = "cbSwitchTable";
            this.cbSwitchTable.Size = new System.Drawing.Size(115, 26);
            this.cbSwitchTable.TabIndex = 7;
            this.cbSwitchTable.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnSwitchTable
            // 
            this.btnSwitchTable.Location = new System.Drawing.Point(3, 25);
            this.btnSwitchTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSwitchTable.Name = "btnSwitchTable";
            this.btnSwitchTable.Size = new System.Drawing.Size(115, 38);
            this.btnSwitchTable.TabIndex = 6;
            this.btnSwitchTable.Text = "Chuyển bàn";
            this.btnSwitchTable.UseVisualStyleBackColor = true;
            // 
            // nmDiscount
            // 
            this.nmDiscount.Location = new System.Drawing.Point(159, 64);
            this.nmDiscount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.nmDiscount.Name = "nmDiscount";
            this.nmDiscount.Size = new System.Drawing.Size(83, 26);
            this.nmDiscount.TabIndex = 4;
            this.nmDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnDiscount
            // 
            this.btnDiscount.Location = new System.Drawing.Point(159, 25);
            this.btnDiscount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDiscount.Name = "btnDiscount";
            this.btnDiscount.Size = new System.Drawing.Size(84, 38);
            this.btnDiscount.TabIndex = 5;
            this.btnDiscount.Text = "Giảm giá";
            this.btnDiscount.UseVisualStyleBackColor = true;
            // 
            // btnCheckOut
            // 
            this.btnCheckOut.Location = new System.Drawing.Point(274, 25);
            this.btnCheckOut.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.Size = new System.Drawing.Size(84, 66);
            this.btnCheckOut.TabIndex = 4;
            this.btnCheckOut.Text = "Thanh toán";
            this.btnCheckOut.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.lsbBill);
            this.panel14.Location = new System.Drawing.Point(420, 268);
            this.panel14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(382, 481);
            this.panel14.TabIndex = 57;
            // 
            // lsbBill
            // 
            this.lsbBill.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader4,
            this.columnHeader3});
            this.lsbBill.GridLines = true;
            this.lsbBill.HideSelection = false;
            this.lsbBill.Location = new System.Drawing.Point(2, 4);
            this.lsbBill.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lsbBill.Name = "lsbBill";
            this.lsbBill.Size = new System.Drawing.Size(375, 590);
            this.lsbBill.TabIndex = 1;
            this.lsbBill.UseCompatibleStateImageBehavior = false;
            this.lsbBill.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Mã Hóa Đơn";
            this.columnHeader1.Width = 88;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Tên Món";
            this.columnHeader2.Width = 61;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Số Lượng";
            this.columnHeader4.Width = 76;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Thành Tiền";
            // 
            // pnlTable
            // 
            this.pnlTable.Controls.Add(this.flpTable);
            this.pnlTable.Location = new System.Drawing.Point(3, 175);
            this.pnlTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnlTable.Name = "pnlTable";
            this.pnlTable.Size = new System.Drawing.Size(413, 704);
            this.pnlTable.TabIndex = 56;
            // 
            // flpTable
            // 
            this.flpTable.AutoScroll = true;
            this.flpTable.Controls.Add(this.flTableQLyBan);
            this.flpTable.Location = new System.Drawing.Point(3, 5);
            this.flpTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.flpTable.Name = "flpTable";
            this.flpTable.Size = new System.Drawing.Size(410, 695);
            this.flpTable.TabIndex = 0;
            // 
            // flTableQLyBan
            // 
            this.flTableQLyBan.Location = new System.Drawing.Point(3, 4);
            this.flTableQLyBan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.flTableQLyBan.Name = "flTableQLyBan";
            this.flTableQLyBan.Size = new System.Drawing.Size(403, 679);
            this.flTableQLyBan.TabIndex = 0;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.Control;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label26.Location = new System.Drawing.Point(310, 95);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(148, 65);
            this.label26.TabIndex = 55;
            this.label26.Text = "BÀN";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(263, 74);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(229, 20);
            this.label21.TabIndex = 53;
            this.label21.Text = "--------------------------------------------";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(316, 52);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(139, 20);
            this.label22.TabIndex = 52;
            this.label22.Text = "SĐT: 0978788799";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(277, 31);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(232, 20);
            this.label24.TabIndex = 51;
            this.label24.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(351, 10);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(45, 20);
            this.label25.TabIndex = 50;
            this.label25.Text = "DNG";
            // 
            // txbThanhToan_HD_chitiet
            // 
            this.txbThanhToan_HD_chitiet.Controls.Add(this.panel15);
            this.txbThanhToan_HD_chitiet.Location = new System.Drawing.Point(4, 29);
            this.txbThanhToan_HD_chitiet.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbThanhToan_HD_chitiet.Name = "txbThanhToan_HD_chitiet";
            this.txbThanhToan_HD_chitiet.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbThanhToan_HD_chitiet.Size = new System.Drawing.Size(830, 939);
            this.txbThanhToan_HD_chitiet.TabIndex = 4;
            this.txbThanhToan_HD_chitiet.Text = "Thanh toán hóa đơn chi tiết";
            this.txbThanhToan_HD_chitiet.UseVisualStyleBackColor = true;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.panel16);
            this.panel15.Controls.Add(this.tbMaHH);
            this.panel15.Controls.Add(this.label37);
            this.panel15.Controls.Add(this.label36);
            this.panel15.Controls.Add(this.label32);
            this.panel15.Controls.Add(this.label33);
            this.panel15.Controls.Add(this.label34);
            this.panel15.Controls.Add(this.label35);
            this.panel15.Location = new System.Drawing.Point(3, 8);
            this.panel15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(1339, 849);
            this.panel15.TabIndex = 0;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Location = new System.Drawing.Point(75, 269);
            this.panel16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(1196, 264);
            this.panel16.TabIndex = 71;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.panel18);
            this.panel17.Controls.Add(this.panel19);
            this.panel17.Controls.Add(this.panel20);
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(1196, 329);
            this.panel17.TabIndex = 2;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.numericUpDown3);
            this.panel18.Controls.Add(this.label38);
            this.panel18.Location = new System.Drawing.Point(3, 134);
            this.panel18.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(1189, 58);
            this.panel18.TabIndex = 3;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(177, 19);
            this.numericUpDown3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(632, 26);
            this.numericUpDown3.TabIndex = 2;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(3, 14);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(129, 29);
            this.label38.TabIndex = 0;
            this.label38.Text = "Số lượng:";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.numericUpDown4);
            this.panel19.Controls.Add(this.lbThanhTien);
            this.panel19.Location = new System.Drawing.Point(3, 199);
            this.panel19.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(1189, 58);
            this.panel19.TabIndex = 3;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(177, 19);
            this.numericUpDown4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(632, 26);
            this.numericUpDown4.TabIndex = 3;
            // 
            // lbThanhTien
            // 
            this.lbThanhTien.AutoSize = true;
            this.lbThanhTien.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbThanhTien.Location = new System.Drawing.Point(3, 14);
            this.lbThanhTien.Name = "lbThanhTien";
            this.lbThanhTien.Size = new System.Drawing.Size(143, 29);
            this.lbThanhTien.TabIndex = 0;
            this.lbThanhTien.Text = "Thành tiền:";
            this.lbThanhTien.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.textBox9);
            this.panel20.Controls.Add(this.lbSoBan);
            this.panel20.Location = new System.Drawing.Point(3, 69);
            this.panel20.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(1189, 58);
            this.panel20.TabIndex = 2;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(166, 16);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(1019, 26);
            this.textBox9.TabIndex = 1;
            // 
            // lbSoBan
            // 
            this.lbSoBan.AutoSize = true;
            this.lbSoBan.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSoBan.Location = new System.Drawing.Point(11, 12);
            this.lbSoBan.Name = "lbSoBan";
            this.lbSoBan.Size = new System.Drawing.Size(101, 29);
            this.lbSoBan.TabIndex = 0;
            this.lbSoBan.Text = "Số bàn:";
            this.lbSoBan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbMaHH
            // 
            this.tbMaHH.Location = new System.Drawing.Point(340, 169);
            this.tbMaHH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbMaHH.Name = "tbMaHH";
            this.tbMaHH.Size = new System.Drawing.Size(618, 26);
            this.tbMaHH.TabIndex = 70;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(303, 175);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(37, 20);
            this.label37.TabIndex = 69;
            this.label37.Text = "Số: ";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.SystemColors.Control;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label36.Location = new System.Drawing.Point(73, 96);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(766, 52);
            this.label36.TabIndex = 68;
            this.label36.Text = "THANH TOÁN HÓA ĐƠN CHI TIẾT";
            this.label36.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(284, 75);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(229, 20);
            this.label32.TabIndex = 67;
            this.label32.Text = "--------------------------------------------";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(336, 54);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(139, 20);
            this.label33.TabIndex = 66;
            this.label33.Text = "SĐT: 0978788799";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(297, 32);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(232, 20);
            this.label34.TabIndex = 65;
            this.label34.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(371, 11);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(45, 20);
            this.label35.TabIndex = 64;
            this.label35.Text = "DNG";
            // 
            // FAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(836, 975);
            this.Controls.Add(this.tcBill);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FAdmin";
            this.Text = "Admin";
            this.tcBill.ResumeLayout(false);
            this.tpFood.ResumeLayout(false);
            this.tpFood.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowMon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDonGia1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMon)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDonGia)).EndInit();
            this.tbCategory.ResumeLayout(false);
            this.tbCategory.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBoxThongTinChung.ResumeLayout(false);
            this.groupBoxThongTinChung.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.groupBoxThongTinHD.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThanhToan_HD)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSoBan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMaHD_Thanhtoan_HD)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.tbBan.ResumeLayout(false);
            this.tbBan.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nmFoodCount)).EndInit();
            this.panel13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cbSwitchTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmDiscount)).EndInit();
            this.panel14.ResumeLayout(false);
            this.pnlTable.ResumeLayout(false);
            this.flpTable.ResumeLayout(false);
            this.txbThanhToan_HD_chitiet.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcBill;
        private System.Windows.Forms.TabPage tpFood;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridViewShowMon;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.NumericUpDown numericUpDownDonGia1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridViewMon;
        private System.Windows.Forms.Label labelGiaTien;
        private System.Windows.Forms.TextBox textBoxTenMon1;
        private System.Windows.Forms.Label labelTenMon1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button buttonXemMon;
        private System.Windows.Forms.Button buttonSuaMon;
        private System.Windows.Forms.Button buttonXoaMon;
        private System.Windows.Forms.Button buttonThemMon;
        private System.Windows.Forms.NumericUpDown numericUpDownDonGia;
        private System.Windows.Forms.TextBox textBoxDVTHH;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxMaHH;
        private System.Windows.Forms.TextBox textBoxTenHH;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TabPage tbCategory;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label labelNhayDup;
        private System.Windows.Forms.GroupBox groupBoxThongTinChung;
        private System.Windows.Forms.ComboBox cboMaNV;
        private System.Windows.Forms.TextBox ComboMaNV;
        private System.Windows.Forms.Label labelMaNV;
        private System.Windows.Forms.TextBox ComboMaKH;
        private System.Windows.Forms.Label labelMaKH;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label labelNV;
        private System.Windows.Forms.Label labelGioVao;
        private System.Windows.Forms.TextBox textBoxKH;
        private System.Windows.Forms.Label labelGioRa;
        private System.Windows.Forms.Label labelMaKhachHang;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DateTimePicker dateTimePickerGioVao;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox textBoxTongTien;
        private System.Windows.Forms.Label labelTongTien;
        private System.Windows.Forms.Button buttonLuu;
        private System.Windows.Forms.Button buttonSua;
        private System.Windows.Forms.Button buttonXoa;
        private System.Windows.Forms.Button buttonThem;
        private System.Windows.Forms.GroupBox groupBoxThongTinHD;
        private System.Windows.Forms.ListView listViewHD_ThanhToan;
        private System.Windows.Forms.ColumnHeader columnHeaderMaHD;
        private System.Windows.Forms.ColumnHeader columnHeaderSoBan;
        private System.Windows.Forms.ColumnHeader columnHeaderGioVao;
        private System.Windows.Forms.ColumnHeader columnHeaderGioRa;
        private System.Windows.Forms.ColumnHeader columnHeaderMaKH;
        private System.Windows.Forms.ColumnHeader columnHeaderMaNV;
        private System.Windows.Forms.ColumnHeader columnHeaderTongTien;
        private System.Windows.Forms.DataGridView dgvThanhToan_HD;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.NumericUpDown numericUpDownSoBan;
        private System.Windows.Forms.NumericUpDown numericUpDownMaHD_Thanhtoan_HD;
        private System.Windows.Forms.TextBox textBoxDonGia;
        private System.Windows.Forms.TextBox textBoxTenMon;
        private System.Windows.Forms.TextBox textBoxThanhTien;
        private System.Windows.Forms.ComboBox cboGiamGia;
        private System.Windows.Forms.Label labelThanhTien;
        private System.Windows.Forms.Label labelGiamGia;
        private System.Windows.Forms.Label labelDonGia;
        private System.Windows.Forms.Label labelSoBan;
        private System.Windows.Forms.Label labelTenMon;
        private System.Windows.Forms.Label labelMaHD;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button buttonTimKiemMaHD;
        private System.Windows.Forms.ComboBox cboMaHD;
        private System.Windows.Forms.Label labelMaHD_TimKiem;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Bang_Hoa_Don;
        private System.Windows.Forms.TabPage tbBan;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.NumericUpDown nmFoodCount;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cbFood;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.NumericUpDown cbSwitchTable;
        private System.Windows.Forms.Button btnSwitchTable;
        private System.Windows.Forms.NumericUpDown nmDiscount;
        private System.Windows.Forms.Button btnDiscount;
        private System.Windows.Forms.Button btnCheckOut;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.ListView lsbBill;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Panel pnlTable;
        private System.Windows.Forms.FlowLayoutPanel flpTable;
        private System.Windows.Forms.FlowLayoutPanel flTableQLyBan;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabPage txbThanhToan_HD_chitiet;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label lbThanhTien;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label lbSoBan;
        private System.Windows.Forms.TextBox tbMaHH;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
    }
}

