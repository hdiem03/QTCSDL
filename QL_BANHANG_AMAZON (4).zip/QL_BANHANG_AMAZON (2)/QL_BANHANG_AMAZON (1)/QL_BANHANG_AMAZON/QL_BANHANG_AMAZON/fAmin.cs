﻿using QL_BANHANG_AMAZON.DAO;
using QL_BANHANG_AMAZON.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QL_BANHANG_AMAZON
{
    public partial class FAdmin : Form
    {
        public FAdmin()
        {
            InitializeComponent();
            LoadListFood();
            LoadTable();
            LoadFoodList();
        }
        #region Method
        void LoadFoodList()
        {
            List<Food> listFood = FoodDAO.Instance.GetListFood();
            cbFood.DataSource = listFood;
            cbFood.DisplayMember = "TenMon";
        }
        void LoadListFood()
        {
            dataGridViewShowMon.DataSource = FoodDAO.Instance.GetListFood();
        }
        void ShowBill1(int soban)
        {
            lsbBill.Items.Clear();
            List<BillInfo1> listbillInfo1 = BillInfo1DAO.Instance.GetListBillInfo1(Bill1DAO.Instance.GetBillSoBanByTableSoBan1(soban));
            foreach (BillInfo1 item1 in listbillInfo1)
            {

                ListViewItem lsvItem1 = new ListViewItem(item1.MaHoaDon.ToString());
                lsvItem1.SubItems.Add(item1.TenMon.ToString());
                lsvItem1.SubItems.Add(item1.SoLuong.ToString());
                lsvItem1.SubItems.Add(item1.ThanhTien.ToString());
                lsbBill.Items.Add(lsvItem1);
            }
            //CultureInfo culture = new CultureInfo("vi-VN");

            //txtTotalThanhTien.Text = ThanhTien.ToString("c", culture);
        }
        void LoadTable()
        {
            List<Table1> tableList = Table1DAO.Instance.LoadTableList();
            foreach (Table1 item in tableList)
            {
                Button btn = new Button() { Width = Table1DAO.TableWildth, Height = Table1DAO.TableHeight };
                btn.Text = item.MaBan + Environment.NewLine + item.SoBan + Environment.NewLine + item.TinhTrang;
                switch (item.TinhTrang)
                {
                    case " Trống":
                        btn.BackColor = Color.White;
                        break;
                    default:
                        btn.BackColor = Color.LightGreen;
                        break;

                }
                btn.Click += btn_Click1;
                btn.Tag = item;
                flTableQLyBan.Controls.Add(btn);


            }
        }
        //void LoadDanhSachMon()
        //{
        //    dataGridViewShowMon.DataSource = FoodDAO.Instance.GetListFood();
        //}
        #endregion
        #region Events
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        void btn_Click1(object sender, EventArgs e)
        {
            int soban = ((sender as Button).Tag as Table1).SoBan;
            ShowBill1(soban);
        }

        private void buttonThemMon_Click(object sender, EventArgs e)
        {
            string tenmon = textBoxTenMon1.Text;
            int giatien = (int)numericUpDownDonGia1.Value;

            if (FoodDAO.Instance.InsertMON(tenmon, giatien))
            {
                MessageBox.Show("Thêm món thành công");
                LoadListFood();

            }
            else
            {
                MessageBox.Show("Có lỗi khi thêm món");
            }

        }

        private void buttonXoaMon_Click(object sender, EventArgs e)
        {
            string tenmon = textBoxTenMon1.Text;
            int giatien = (int)numericUpDownDonGia1.Value;

            if (FoodDAO.Instance.DeleteMON(tenmon, giatien))
            {
                MessageBox.Show("Xóa hóa đơn thành công");
                LoadListFood();

            }
            else
            {
                MessageBox.Show("Có lỗi khi xóa món");
            }
        }

        private void buttonSuaMon_Click(object sender, EventArgs e)
        {
            string tenmon = textBoxTenMon1.Text;
            int giatien = (int)numericUpDownDonGia1.Value;

            if (FoodDAO.Instance.UpdateMON(tenmon, giatien))
            {
                MessageBox.Show("Sửa món thành công");
                LoadListFood();

            }
            else
            {
                MessageBox.Show("Có lỗi khi sửa món");
            }
        }

        private void ComboMaKH_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonThem_Click(object sender, EventArgs e)
        {
            int mahoadon = (int)numericUpDownMaHD_Thanhtoan_HD.Value;
            int soban = (int)numericUpDownSoBan.Value;
            string makh = ComboMaKH.Text;
            string manv = ComboMaNV.Text;
            //int tongtien = (int)numericUpDownTongTien.Value;
            if (Bill1DAO.Instance.InsertBill1(mahoadon, soban, makh, manv))
            {
                MessageBox.Show("Thêm hóa đơn thành công");
                LoadListFood();

            }
            else
            {
                MessageBox.Show("Có lỗi khi thêm hóa đơn");
            }

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tbCategory_Click(object sender, EventArgs e)
        {

        }

        private void cbFood_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
    #endregion
}