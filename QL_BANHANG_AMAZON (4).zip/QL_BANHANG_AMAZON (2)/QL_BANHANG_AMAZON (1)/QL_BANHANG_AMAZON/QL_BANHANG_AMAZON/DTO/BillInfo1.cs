﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QL_BANHANG_AMAZON.DTO
{
    public class BillInfo1
    {
        public BillInfo1(string mahoadon, string tenmon, int soluong, float thanhtien)
        {
            this.MaHoaDon = mahoadon;
            this.TenMon = tenmon;
            this.SoLuong = soluong;
            this.ThanhTien = thanhtien;

        }
        public BillInfo1(DataRow row)
        {
            this.MaHoaDon = row["mahoadon"].ToString();
            this.TenMon = row["tenmon"].ToString();
            this.SoLuong = (int)row["soluong"];
            this.ThanhTien = (float)Convert.ToDouble(row["thanhtien"].ToString());
        }
        private string mahoadon;
        public string MaHoaDon
        {
            get { return mahoadon; }
            set { mahoadon = value; }

        }
        private string tenmon;
        public string TenMon
        {
            get { return tenmon; }
            set { tenmon = value; }

        }
        private int soluong;
        public int SoLuong
        {
            get { return soluong; }
            set { soluong = value; }

        }
        private float thanhtien;
        public float ThanhTien
        {
            get { return thanhtien; }
            set { thanhtien = value; }

        }

    }
}
