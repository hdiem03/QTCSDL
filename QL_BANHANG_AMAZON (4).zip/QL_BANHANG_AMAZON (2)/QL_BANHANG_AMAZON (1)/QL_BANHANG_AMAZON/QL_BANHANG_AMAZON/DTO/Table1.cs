﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QL_BANHANG_AMAZON.DTO
{
    public class Table1
    {
        public Table1(int MaBan, int SoBan, string TinhTrang)
        {
            this.MaBan = MaBan;
            this.SoBan = SoBan;
            this.TinhTrang = TinhTrang;
        }
        //public Table1(DataRow row)
        //{

        //    this.MaBan = (int)row["maban"];
        //    this.SoBan = (int)row["soban"];
        //}
        public Table1(DataRow row)
        {
            if (row["MaBan"] != DBNull.Value)
            {
                if (row["MaBan"] is int)
                    this.MaBan = (int)row["MaBan"];
                else if (row["MaBan"] is decimal)
                    this.MaBan = Convert.ToInt32((decimal)row["MaBan"]);
                // Add more type checks if needed
                else
                    this.MaBan = 0; // or another default value if the type is not allowed
            }
            else
                this.MaBan = 0; // or another default value if DBNull is not allowed

            if (row["SoBan"] != DBNull.Value)
            {
                if (row["SoBan"] is int)
                    this.SoBan = (int)row["SoBan"];
                else if (row["SoBan"] is decimal)
                    this.SoBan = Convert.ToInt32((decimal)row["SoBan"]);
                // Add more type checks if needed
                else
                    this.SoBan = 0; // or another default value if the type is not allowed
            }
            else
                this.SoBan = 0; // or another default value if DBNull is not allowed
            this.TinhTrang = row["tinhtrang"].ToString();
        }
        private int maban;
        public int MaBan
        {
            get { return maban; }
            set { maban = value; }
        }
        private int soban;
        public int SoBan
        {
            get { return soban; }
            set { soban = value; }
        }
        private string tinhtrang;
        public string TinhTrang
        {
            get { return tinhtrang; }
            set { tinhtrang = value; }
        }

    }
}
