﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QL_BANHANG_AMAZON.DTO
{
    public class Bill1
    {
        public Bill1(int mahoadon, int soban, DateTime? giovao, DateTime? giora, string makh, string manv)
        {
            this.MaHoaDon = mahoadon;
            this.SoBan = soban;
            this.GioVao = giovao;
            this.GioRa = giora;
            this.MaKH = makh;
            this.MaNV = manv;
            this.MaNV = manv; 

        }
        public Bill1(DataRow row)
        {

            this.MaHoaDon = (int)row["mahoadon"];
            this.SoBan = (int)row["soban"];
            var giovao = row["giovao"];
            if (giovao.ToString() != "")
                this.GioVao = (DateTime?)giovao;
            var giora = row["giora"];
            if (giora != null)
                this.GioRa = (DateTime?)giora;
            this.MaKH = row["makh"].ToString();
            this.MaNV = row["manv"].ToString();
            this.TongTien = (int)row["tongtien"];
        }
        private int mahoadon;
        public int MaHoaDon
        {
            get { return mahoadon; }
            set { mahoadon = value; }

        }
        private int soban;
        public int SoBan
        {
            get { return soban; }
            set { soban = value; }

        }
        private DateTime? giovao;
        public DateTime? GioVao
        {
            get { return giovao; }
            set { giovao = value; }

        }
        private DateTime? giora;
        public DateTime? GioRa
        {
            get { return giora; }
            set { giora = value; }

        }

        private string makh;
        public string MaKH
        {
            get { return makh; }
            set { makh = value; }

        }
        private string manv;
        public string MaNV
        {
            get { return manv; }
            set { manv = value; }

        }
        private int tongtien;
        public int TongTien
        {
            get { return tongtien; }
            set { tongtien = value; }

        }
    }
}
