﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QL_BANHANG_AMAZON.DAO
{
    public class DataProvider
    {
        private static DataProvider instance;
        public static DataProvider Instance
        {
            get { if (instance == null) instance = new DataProvider(); return DataProvider.instance; }
            private set { DataProvider.instance = value; }
        }
        private DataProvider() 
        {
            SqlConnection connection = new SqlConnection(connectionSTR);
            Con = connection;
        }
        private string connectionSTR = "Data Source=HUYNHANH\\ANH;Initial Catalog=Quanlycaphe;Integrated Security=True";

        //internal DataTable ExecuteQuery()
        //{
        //    throw new NotImplementedException();
        //}

        public DataTable ExecuteQuery(string query, object[] parameter = null)
        {
            DataTable data = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionSTR))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                if (parameter != null)
                {
                    string[] listPara = query.Split(' ');
                    int i = 0;
                    foreach (string item in listPara)
                    {
                        if (item.Contains('@'))
                        {
                            command.Parameters.AddWithValue(item, parameter[i]);
                            i++;
                        }
                    }
                }
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(data);
                connection.Close();
            }

            return data;
        }
        public int ExecuteNonQuery(string query, object[] parameter = null)
        {
            int data = 0;
            using (SqlConnection connection = new SqlConnection(connectionSTR))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                if (parameter != null)
                {
                    string[] listPara = query.Split(' ');
                    int i = 0;
                    foreach (string item in listPara)
                    {
                        if (item.Contains('@'))
                        {
                            command.Parameters.AddWithValue(item, parameter[i]);
                            i++;
                        }
                    }
                }
                data = command.ExecuteNonQuery();
                connection.Close();
            }

            return data;
        }
        internal IDisposable GetConnection()
        {
            throw new NotImplementedException();
        }
        public object ExecuteScalar(string query, object[] parameter = null)
        {
            object data = 0;
            using (SqlConnection connection = new SqlConnection(connectionSTR))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                if (parameter != null)
                {
                    string[] listPara = query.Split(' ');
                    int i = 0;
                    foreach (string item in listPara)
                    {
                        if (item.Contains('@'))
                        {
                            command.Parameters.AddWithValue(item, parameter[i]);
                            i++;
                        }
                    }
                }
                data = command.ExecuteScalar();
                connection.Close();
            }

            return data;
        }
        public static SqlConnection Con;
        public static void Connect()
        {
            Con = new SqlConnection();   //Khởi tạo đối tượng
            //Con.ConnectionString = Properties.Settings.Default.QlyHangHoaConnectionString;
            Con.ConnectionString = "Data Source=LAPTOP-05IGM9J7\\MAYAO;Initial Catalog=Quanlycaphe;Integrated Security=True";
            if (Con.State != ConnectionState.Open)
            {
                Con.Open();
                MessageBox.Show("Kết nối thành công!");

            }
            else
                MessageBox.Show("Kết nối không thành công!");
        }
        // TẠO PHƯƠNG THỨC DISCONNECT
        public static void Disconnect()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
                Con.Dispose();
                Con = null;
            }

        }
        //Phương thức thực thi câu lệnh select lấy dữ liệu
        public static DataTable GetDataToTable(string sql)
        {
            SqlDataAdapter dap = new SqlDataAdapter(sql, Con); //Định nghĩa đối tượng thuộc lớp SqlDataAdapter
            //Khai báo đối tượng table thuộc lớp DataTable
            //Tạo đối tượng thuộc lớp SqlCommand
            DataProvider.Connect();
            dap.SelectCommand = new SqlCommand();
            dap.SelectCommand.Connection = DataProvider.Con; //Kết nối cơ sở dữ liệu
            dap.SelectCommand.CommandText = sql; //Lệnh SQL
            DataTable table = new DataTable();
            dap.Fill(table); //Đổ kết quả từ câu lệnh sql vào table
            return table;
        }
        //Phương thức thực thi câu lệnh insert, update,delete
        public static void RunSQL(string sql)
        {
            SqlCommand cmd; //Đối tượng thuộc lớp SqlCommand
            cmd = new SqlCommand();
            cmd.Connection = Con; //Gán kết nối
            cmd.CommandText = sql; //Gán lệnh SQL
            try
            {
                cmd.ExecuteNonQuery(); //Thực hiện câu lệnh SQL
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            cmd.Dispose();//Giải phóng bộ nhớ
            cmd = null;
        }
        //Hàm kiểm tra khoá trùng
        public static bool CheckKey(string sql)
        {
            SqlDataAdapter dap = new SqlDataAdapter(sql, Con);
            DataTable table = new DataTable();
            dap.Fill(table);
            if (table.Rows.Count > 0)
                return true;
            else return false;
        }
        public static void FillCombo(string sql, ComboBox cbo, string ma, string ten)
        {
            using (SqlConnection connection = new SqlConnection(Con.ConnectionString))
            {
                // Khởi tạo SqlCommand và gán giá trị cho Connection
                SqlCommand command = new SqlCommand(sql, connection);

                // Mở kết nối trước khi sử dụng
                connection.Open();

                // Khởi tạo SqlDataAdapter
                SqlDataAdapter adapter = new SqlDataAdapter(command);

                // Khởi tạo DataTable
                DataTable dataTable = new DataTable();

                // Sử dụng phương thức Fill để điền dữ liệu vào DataTable
                adapter.Fill(dataTable);

                // Gán DataTable làm nguồn dữ liệu cho ComboBox
                cbo.DataSource = dataTable;

                // Thiết lập cột hiển thị và giá trị tương ứng
                cbo.DisplayMember = ten;
                cbo.ValueMember = ma;

                // Đóng kết nối sau khi sử dụng
                connection.Close();
            }
        }
        public static string GetFieldValues(string sql)
        {
            string ma = "";
            using (SqlConnection connection = new SqlConnection(Con.ConnectionString))
            {
                connection.Open();

                using (SqlCommand cmd = new SqlCommand(sql, connection))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        ma = reader.GetValue(0).ToString();
                    }
                    reader.Close();
                }

                connection.Close();
            }
            return ma;
        }

    }
}
