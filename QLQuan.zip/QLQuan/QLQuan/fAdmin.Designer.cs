﻿
namespace QLQuan
{
    partial class fAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fAdmin));
            this.tbBan = new System.Windows.Forms.TabPage();
            this.panel21 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label26 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txbStatus = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.txbTableNumber = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.txbtxbTableName1 = new System.Windows.Forms.TextBox();
            this.txbTableName = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.btnViewTable = new System.Windows.Forms.Button();
            this.btnEditTable = new System.Windows.Forms.Button();
            this.btnDeleteTable = new System.Windows.Forms.Button();
            this.btnAddTable = new System.Windows.Forms.Button();
            this.panel34 = new System.Windows.Forms.Panel();
            this.tpFood = new System.Windows.Forms.TabPage();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txbSearchFoodName = new System.Windows.Forms.TextBox();
            this.btnSearchFood = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txbTenMon = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnShowFood = new System.Windows.Forms.Button();
            this.btnEditFood = new System.Windows.Forms.Button();
            this.btnDeleteFood = new System.Windows.Forms.Button();
            this.btnAddFood = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dtgvFood = new System.Windows.Forms.DataGridView();
            this.tcBill = new System.Windows.Forms.TabControl();
            this.tbCategory = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dgvHoaDonBanHang = new System.Windows.Forms.DataGridView();
            this.panel13 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.cboGiamGia = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cboDonGia = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cboSoLuong = new System.Windows.Forms.ComboBox();
            this.cboTenHang = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboMahang = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.cboMaHD = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.Bang_Hoa_Don = new System.Windows.Forms.Label();
            this.txbThanhToan_HD_chitiet = new System.Windows.Forms.TabPage();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.lbThanhTien = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.lbSoBan = new System.Windows.Forms.Label();
            this.tbMaHH = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tbBan.SuspendLayout();
            this.panel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel26.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.tpFood.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.panel10.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFood)).BeginInit();
            this.tcBill.SuspendLayout();
            this.tbCategory.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDonBanHang)).BeginInit();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.txbThanhToan_HD_chitiet.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.panel20.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbBan
            // 
            this.tbBan.Controls.Add(this.panel21);
            this.tbBan.Controls.Add(this.label26);
            this.tbBan.Controls.Add(this.label21);
            this.tbBan.Controls.Add(this.label22);
            this.tbBan.Controls.Add(this.label24);
            this.tbBan.Controls.Add(this.label25);
            this.tbBan.Controls.Add(this.panel26);
            this.tbBan.Controls.Add(this.panel28);
            this.tbBan.Controls.Add(this.panel33);
            this.tbBan.Location = new System.Drawing.Point(4, 25);
            this.tbBan.Name = "tbBan";
            this.tbBan.Padding = new System.Windows.Forms.Padding(3);
            this.tbBan.Size = new System.Drawing.Size(776, 741);
            this.tbBan.TabIndex = 3;
            this.tbBan.Text = "Bàn";
            this.tbBan.UseVisualStyleBackColor = true;
            this.tbBan.Click += new System.EventHandler(this.tbBan_Click);
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.dataGridView2);
            this.panel21.Location = new System.Drawing.Point(8, 211);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(441, 308);
            this.panel21.TabIndex = 56;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(-3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(446, 302);
            this.dataGridView2.TabIndex = 6;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.Control;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label26.Location = new System.Drawing.Point(309, 71);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(126, 55);
            this.label26.TabIndex = 55;
            this.label26.Text = "BÀN";
            this.label26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(267, 54);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(228, 17);
            this.label21.TabIndex = 53;
            this.label21.Text = "--------------------------------------------";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(314, 37);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(124, 17);
            this.label22.TabIndex = 52;
            this.label22.Text = "SĐT: 0978788799";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(279, 20);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(206, 17);
            this.label24.TabIndex = 51;
            this.label24.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(345, 3);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(39, 17);
            this.label25.TabIndex = 50;
            this.label25.Text = "DNG";
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.textBox4);
            this.panel26.Controls.Add(this.button10);
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Location = new System.Drawing.Point(453, 132);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(319, 76);
            this.panel26.TabIndex = 5;
            this.panel26.Paint += new System.Windows.Forms.PaintEventHandler(this.panel26_Paint);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(3, 23);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(232, 22);
            this.textBox4.TabIndex = 7;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(241, 3);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 70);
            this.button10.TabIndex = 6;
            this.button10.Text = "Tìm";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // panel27
            // 
            this.panel27.Location = new System.Drawing.Point(0, -116);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(441, 86);
            this.panel27.TabIndex = 1;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.panel1);
            this.panel28.Controls.Add(this.panel31);
            this.panel28.Controls.Add(this.panel32);
            this.panel28.Location = new System.Drawing.Point(453, 214);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(319, 223);
            this.panel28.TabIndex = 3;
            this.panel28.Paint += new System.Windows.Forms.PaintEventHandler(this.panel28_Paint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.txbStatus);
            this.panel1.Location = new System.Drawing.Point(4, 107);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(313, 46);
            this.panel1.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(148, 13);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(148, 22);
            this.textBox1.TabIndex = 1;
            // 
            // txbStatus
            // 
            this.txbStatus.AutoSize = true;
            this.txbStatus.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbStatus.Location = new System.Drawing.Point(3, 11);
            this.txbStatus.Name = "txbStatus";
            this.txbStatus.Size = new System.Drawing.Size(116, 24);
            this.txbStatus.TabIndex = 0;
            this.txbStatus.Text = "Tình trạng:";
            this.txbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.textBox5);
            this.panel31.Controls.Add(this.txbTableNumber);
            this.panel31.Location = new System.Drawing.Point(3, 55);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(313, 46);
            this.panel31.TabIndex = 2;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(148, 13);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(148, 22);
            this.textBox5.TabIndex = 1;
            // 
            // txbTableNumber
            // 
            this.txbTableNumber.AutoSize = true;
            this.txbTableNumber.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTableNumber.Location = new System.Drawing.Point(3, 11);
            this.txbTableNumber.Name = "txbTableNumber";
            this.txbTableNumber.Size = new System.Drawing.Size(83, 24);
            this.txbTableNumber.TabIndex = 0;
            this.txbTableNumber.Text = "Số bàn:";
            this.txbTableNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.txbtxbTableName1);
            this.panel32.Controls.Add(this.txbTableName);
            this.panel32.Location = new System.Drawing.Point(3, 3);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(313, 46);
            this.panel32.TabIndex = 1;
            // 
            // txbtxbTableName1
            // 
            this.txbtxbTableName1.Location = new System.Drawing.Point(148, 13);
            this.txbtxbTableName1.Name = "txbtxbTableName1";
            this.txbtxbTableName1.Size = new System.Drawing.Size(148, 22);
            this.txbtxbTableName1.TabIndex = 1;
            // 
            // txbTableName
            // 
            this.txbTableName.AutoSize = true;
            this.txbTableName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbTableName.Location = new System.Drawing.Point(3, 11);
            this.txbTableName.Name = "txbTableName";
            this.txbTableName.Size = new System.Drawing.Size(86, 24);
            this.txbTableName.TabIndex = 0;
            this.txbTableName.Text = "Mã bàn:";
            this.txbTableName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txbTableName.Click += new System.EventHandler(this.label14_Click);
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.btnViewTable);
            this.panel33.Controls.Add(this.btnEditTable);
            this.panel33.Controls.Add(this.btnDeleteTable);
            this.panel33.Controls.Add(this.btnAddTable);
            this.panel33.Controls.Add(this.panel34);
            this.panel33.Location = new System.Drawing.Point(6, 132);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(441, 76);
            this.panel33.TabIndex = 4;
            // 
            // btnViewTable
            // 
            this.btnViewTable.Location = new System.Drawing.Point(354, 0);
            this.btnViewTable.Name = "btnViewTable";
            this.btnViewTable.Size = new System.Drawing.Size(75, 70);
            this.btnViewTable.TabIndex = 5;
            this.btnViewTable.Text = "Xem";
            this.btnViewTable.UseVisualStyleBackColor = true;
            // 
            // btnEditTable
            // 
            this.btnEditTable.Location = new System.Drawing.Point(237, 3);
            this.btnEditTable.Name = "btnEditTable";
            this.btnEditTable.Size = new System.Drawing.Size(75, 70);
            this.btnEditTable.TabIndex = 4;
            this.btnEditTable.Text = "Sửa";
            this.btnEditTable.UseVisualStyleBackColor = true;
            // 
            // btnDeleteTable
            // 
            this.btnDeleteTable.Location = new System.Drawing.Point(119, 3);
            this.btnDeleteTable.Name = "btnDeleteTable";
            this.btnDeleteTable.Size = new System.Drawing.Size(75, 70);
            this.btnDeleteTable.TabIndex = 3;
            this.btnDeleteTable.Text = "Xóa";
            this.btnDeleteTable.UseVisualStyleBackColor = true;
            // 
            // btnAddTable
            // 
            this.btnAddTable.Location = new System.Drawing.Point(3, 3);
            this.btnAddTable.Name = "btnAddTable";
            this.btnAddTable.Size = new System.Drawing.Size(75, 70);
            this.btnAddTable.TabIndex = 2;
            this.btnAddTable.Text = "Thêm";
            this.btnAddTable.UseVisualStyleBackColor = true;
            // 
            // panel34
            // 
            this.panel34.Location = new System.Drawing.Point(0, -116);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(441, 86);
            this.panel34.TabIndex = 1;
            // 
            // tpFood
            // 
            this.tpFood.Controls.Add(this.label27);
            this.tpFood.Controls.Add(this.label28);
            this.tpFood.Controls.Add(this.label29);
            this.tpFood.Controls.Add(this.label30);
            this.tpFood.Controls.Add(this.label31);
            this.tpFood.Controls.Add(this.panel7);
            this.tpFood.Controls.Add(this.panel5);
            this.tpFood.Controls.Add(this.panel4);
            this.tpFood.Controls.Add(this.panel3);
            this.tpFood.Location = new System.Drawing.Point(4, 25);
            this.tpFood.Name = "tpFood";
            this.tpFood.Padding = new System.Windows.Forms.Padding(3);
            this.tpFood.Size = new System.Drawing.Size(776, 741);
            this.tpFood.TabIndex = 1;
            this.tpFood.Text = "Món";
            this.tpFood.UseVisualStyleBackColor = true;
            this.tpFood.Click += new System.EventHandler(this.tpFood_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(247, 67);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(228, 17);
            this.label27.TabIndex = 70;
            this.label27.Text = "--------------------------------------------";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(294, 50);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(124, 17);
            this.label28.TabIndex = 69;
            this.label28.Text = "SĐT: 0978788799";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(259, 33);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(206, 17);
            this.label29.TabIndex = 68;
            this.label29.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(325, 16);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(39, 17);
            this.label30.TabIndex = 67;
            this.label30.Text = "DNG";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.Control;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label31.Location = new System.Drawing.Point(279, 111);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(139, 55);
            this.label31.TabIndex = 66;
            this.label31.Text = "MÓN";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txbSearchFoodName);
            this.panel7.Controls.Add(this.btnSearchFood);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Location = new System.Drawing.Point(451, 225);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(319, 76);
            this.panel7.TabIndex = 2;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // txbSearchFoodName
            // 
            this.txbSearchFoodName.Location = new System.Drawing.Point(3, 23);
            this.txbSearchFoodName.Name = "txbSearchFoodName";
            this.txbSearchFoodName.Size = new System.Drawing.Size(232, 22);
            this.txbSearchFoodName.TabIndex = 7;
            this.txbSearchFoodName.TextChanged += new System.EventHandler(this.txbSearchFoodName_TextChanged);
            // 
            // btnSearchFood
            // 
            this.btnSearchFood.Location = new System.Drawing.Point(241, 3);
            this.btnSearchFood.Name = "btnSearchFood";
            this.btnSearchFood.Size = new System.Drawing.Size(75, 70);
            this.btnSearchFood.TabIndex = 6;
            this.btnSearchFood.Text = "Tìm";
            this.btnSearchFood.UseVisualStyleBackColor = true;
            this.btnSearchFood.Click += new System.EventHandler(this.btnSearchFood_Click);
            // 
            // panel8
            // 
            this.panel8.Location = new System.Drawing.Point(0, -116);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(441, 86);
            this.panel8.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel11);
            this.panel5.Controls.Add(this.panel10);
            this.panel5.Location = new System.Drawing.Point(453, 307);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(319, 223);
            this.panel5.TabIndex = 1;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.numericUpDown2);
            this.panel11.Controls.Add(this.label3);
            this.panel11.Location = new System.Drawing.Point(3, 135);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(313, 46);
            this.panel11.TabIndex = 3;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(157, 15);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(139, 22);
            this.numericUpDown2.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "Giá tiền:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.txbTenMon);
            this.panel10.Controls.Add(this.label2);
            this.panel10.Location = new System.Drawing.Point(3, 55);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(313, 46);
            this.panel10.TabIndex = 2;
            this.panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel10_Paint);
            // 
            // txbTenMon
            // 
            this.txbTenMon.Location = new System.Drawing.Point(148, 13);
            this.txbTenMon.Name = "txbTenMon";
            this.txbTenMon.Size = new System.Drawing.Size(148, 22);
            this.txbTenMon.TabIndex = 1;
            this.txbTenMon.TextChanged += new System.EventHandler(this.txbTenMon_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên món:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnShowFood);
            this.panel4.Controls.Add(this.btnEditFood);
            this.panel4.Controls.Add(this.btnDeleteFood);
            this.panel4.Controls.Add(this.btnAddFood);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Location = new System.Drawing.Point(7, 225);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(441, 76);
            this.panel4.TabIndex = 1;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // btnShowFood
            // 
            this.btnShowFood.Location = new System.Drawing.Point(354, 0);
            this.btnShowFood.Name = "btnShowFood";
            this.btnShowFood.Size = new System.Drawing.Size(75, 70);
            this.btnShowFood.TabIndex = 5;
            this.btnShowFood.Text = "Xem";
            this.btnShowFood.UseVisualStyleBackColor = true;
            this.btnShowFood.Click += new System.EventHandler(this.btnShowFood_Click);
            // 
            // btnEditFood
            // 
            this.btnEditFood.Location = new System.Drawing.Point(237, 3);
            this.btnEditFood.Name = "btnEditFood";
            this.btnEditFood.Size = new System.Drawing.Size(75, 70);
            this.btnEditFood.TabIndex = 4;
            this.btnEditFood.Text = "Sửa";
            this.btnEditFood.UseVisualStyleBackColor = true;
            this.btnEditFood.Click += new System.EventHandler(this.btnEditFood_Click);
            // 
            // btnDeleteFood
            // 
            this.btnDeleteFood.Location = new System.Drawing.Point(119, 3);
            this.btnDeleteFood.Name = "btnDeleteFood";
            this.btnDeleteFood.Size = new System.Drawing.Size(75, 70);
            this.btnDeleteFood.TabIndex = 3;
            this.btnDeleteFood.Text = "Xóa";
            this.btnDeleteFood.UseVisualStyleBackColor = true;
            this.btnDeleteFood.Click += new System.EventHandler(this.btnDeleteFood_Click);
            // 
            // btnAddFood
            // 
            this.btnAddFood.Location = new System.Drawing.Point(3, 3);
            this.btnAddFood.Name = "btnAddFood";
            this.btnAddFood.Size = new System.Drawing.Size(75, 70);
            this.btnAddFood.TabIndex = 2;
            this.btnAddFood.Text = "Thêm";
            this.btnAddFood.UseVisualStyleBackColor = true;
            this.btnAddFood.Click += new System.EventHandler(this.btnAddFood_Click);
            // 
            // panel6
            // 
            this.panel6.Location = new System.Drawing.Point(0, -116);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(441, 86);
            this.panel6.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dtgvFood);
            this.panel3.Location = new System.Drawing.Point(6, 307);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(441, 308);
            this.panel3.TabIndex = 0;
            // 
            // dtgvFood
            // 
            this.dtgvFood.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvFood.Location = new System.Drawing.Point(4, 6);
            this.dtgvFood.Name = "dtgvFood";
            this.dtgvFood.RowHeadersWidth = 51;
            this.dtgvFood.RowTemplate.Height = 24;
            this.dtgvFood.Size = new System.Drawing.Size(435, 302);
            this.dtgvFood.TabIndex = 2;
            this.dtgvFood.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvFood_CellContentClick);
            // 
            // tcBill
            // 
            this.tcBill.Controls.Add(this.tpFood);
            this.tcBill.Controls.Add(this.tbCategory);
            this.tcBill.Controls.Add(this.tbBan);
            this.tcBill.Controls.Add(this.txbThanhToan_HD_chitiet);
            this.tcBill.Location = new System.Drawing.Point(0, 12);
            this.tcBill.Name = "tcBill";
            this.tcBill.SelectedIndex = 0;
            this.tcBill.Size = new System.Drawing.Size(784, 770);
            this.tcBill.TabIndex = 0;
            this.tcBill.SelectedIndexChanged += new System.EventHandler(this.tcBill_SelectedIndexChanged);
            // 
            // tbCategory
            // 
            this.tbCategory.Controls.Add(this.panel2);
            this.tbCategory.Controls.Add(this.label20);
            this.tbCategory.Controls.Add(this.groupBox1);
            this.tbCategory.Controls.Add(this.dateTimePicker2);
            this.tbCategory.Controls.Add(this.dateTimePicker1);
            this.tbCategory.Controls.Add(this.textBox6);
            this.tbCategory.Controls.Add(this.textBox7);
            this.tbCategory.Controls.Add(this.textBox8);
            this.tbCategory.Controls.Add(this.panel14);
            this.tbCategory.Controls.Add(this.label15);
            this.tbCategory.Controls.Add(this.label14);
            this.tbCategory.Controls.Add(this.label6);
            this.tbCategory.Controls.Add(this.label7);
            this.tbCategory.Controls.Add(this.label12);
            this.tbCategory.Controls.Add(this.label11);
            this.tbCategory.Controls.Add(this.label10);
            this.tbCategory.Controls.Add(this.label9);
            this.tbCategory.Controls.Add(this.label18);
            this.tbCategory.Controls.Add(this.Bang_Hoa_Don);
            this.tbCategory.Location = new System.Drawing.Point(4, 25);
            this.tbCategory.Name = "tbCategory";
            this.tbCategory.Padding = new System.Windows.Forms.Padding(3);
            this.tbCategory.Size = new System.Drawing.Size(776, 741);
            this.tbCategory.TabIndex = 2;
            this.tbCategory.Text = "Thanh toán hóa đơn";
            this.tbCategory.UseVisualStyleBackColor = true;
            this.tbCategory.Click += new System.EventHandler(this.tbCategory_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Location = new System.Drawing.Point(0, 659);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 41);
            this.panel2.TabIndex = 53;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(404, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(69, 32);
            this.button2.TabIndex = 5;
            this.button2.Text = "Xem";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(635, 11);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(127, 22);
            this.textBox3.TabIndex = 32;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(261, 6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(69, 32);
            this.button3.TabIndex = 4;
            this.button3.Text = "Sửa";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(562, 14);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 17);
            this.label19.TabIndex = 12;
            this.label19.Text = "Tổng tiền:";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(138, 6);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(69, 32);
            this.button4.TabIndex = 3;
            this.button4.Text = "Xóa";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(26, 6);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(69, 32);
            this.button5.TabIndex = 2;
            this.button5.Text = "Thêm";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(71, 187);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 17);
            this.label20.TabIndex = 71;
            this.label20.Text = "Giờ vào:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel9);
            this.groupBox1.Controls.Add(this.panel13);
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox1.Location = new System.Drawing.Point(3, 286);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(797, 407);
            this.groupBox1.TabIndex = 70;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông tin các mặt hàng";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.dgvHoaDonBanHang);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(3, 92);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(791, 312);
            this.panel9.TabIndex = 1;
            // 
            // dgvHoaDonBanHang
            // 
            this.dgvHoaDonBanHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoaDonBanHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvHoaDonBanHang.Location = new System.Drawing.Point(0, 0);
            this.dgvHoaDonBanHang.Name = "dgvHoaDonBanHang";
            this.dgvHoaDonBanHang.RowHeadersWidth = 51;
            this.dgvHoaDonBanHang.RowTemplate.Height = 24;
            this.dgvHoaDonBanHang.Size = new System.Drawing.Size(791, 312);
            this.dgvHoaDonBanHang.TabIndex = 0;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.textBox2);
            this.panel13.Controls.Add(this.cboGiamGia);
            this.panel13.Controls.Add(this.label17);
            this.panel13.Controls.Add(this.label16);
            this.panel13.Controls.Add(this.cboDonGia);
            this.panel13.Controls.Add(this.label13);
            this.panel13.Controls.Add(this.label8);
            this.panel13.Controls.Add(this.cboSoLuong);
            this.panel13.Controls.Add(this.cboTenHang);
            this.panel13.Controls.Add(this.label1);
            this.panel13.Controls.Add(this.cboMahang);
            this.panel13.Controls.Add(this.label5);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel13.Location = new System.Drawing.Point(3, 18);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(791, 74);
            this.panel13.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(637, 34);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(119, 22);
            this.textBox2.TabIndex = 32;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // cboGiamGia
            // 
            this.cboGiamGia.FormattingEnabled = true;
            this.cboGiamGia.Location = new System.Drawing.Point(384, 35);
            this.cboGiamGia.Name = "cboGiamGia";
            this.cboGiamGia.Size = new System.Drawing.Size(119, 24);
            this.cboGiamGia.TabIndex = 11;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(530, 39);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(80, 17);
            this.label17.TabIndex = 6;
            this.label17.Text = "Thành tiền:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(277, 39);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 17);
            this.label16.TabIndex = 10;
            this.label16.Text = "Giảm giá:";
            // 
            // cboDonGia
            // 
            this.cboDonGia.FormattingEnabled = true;
            this.cboDonGia.Location = new System.Drawing.Point(637, 5);
            this.cboDonGia.Name = "cboDonGia";
            this.cboDonGia.Size = new System.Drawing.Size(119, 24);
            this.cboDonGia.TabIndex = 9;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(530, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 17);
            this.label13.TabIndex = 8;
            this.label13.Text = "Đơn giá:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 42);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 17);
            this.label8.TabIndex = 7;
            this.label8.Text = "Số lượng:";
            // 
            // cboSoLuong
            // 
            this.cboSoLuong.FormattingEnabled = true;
            this.cboSoLuong.Location = new System.Drawing.Point(143, 39);
            this.cboSoLuong.Name = "cboSoLuong";
            this.cboSoLuong.Size = new System.Drawing.Size(48, 24);
            this.cboSoLuong.TabIndex = 6;
            // 
            // cboTenHang
            // 
            this.cboTenHang.FormattingEnabled = true;
            this.cboTenHang.Location = new System.Drawing.Point(384, 6);
            this.cboTenHang.Name = "cboTenHang";
            this.cboTenHang.Size = new System.Drawing.Size(119, 24);
            this.cboTenHang.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(277, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tên hàng hóa:";
            // 
            // cboMahang
            // 
            this.cboMahang.FormattingEnabled = true;
            this.cboMahang.Location = new System.Drawing.Point(143, 6);
            this.cboMahang.Name = "cboMahang";
            this.cboMahang.Size = new System.Drawing.Size(119, 24);
            this.cboMahang.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 17);
            this.label5.TabIndex = 3;
            this.label5.Text = "Mã hàng hóa:";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker2.Location = new System.Drawing.Point(496, 186);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(133, 22);
            this.dateTimePicker2.TabIndex = 69;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker1.Location = new System.Drawing.Point(138, 186);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(129, 22);
            this.dateTimePicker1.TabIndex = 68;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(138, 231);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(127, 22);
            this.textBox6.TabIndex = 67;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(291, 152);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(127, 22);
            this.textBox7.TabIndex = 66;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(291, 124);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(127, 22);
            this.textBox8.TabIndex = 65;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.button1);
            this.panel14.Controls.Add(this.cboMaHD);
            this.panel14.Controls.Add(this.label23);
            this.panel14.Location = new System.Drawing.Point(0, 699);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(800, 100);
            this.panel14.TabIndex = 64;
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button1.Location = new System.Drawing.Point(292, 7);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "&Tìm Kiếm";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // cboMaHD
            // 
            this.cboMaHD.FormattingEnabled = true;
            this.cboMaHD.Location = new System.Drawing.Point(101, 10);
            this.cboMaHD.Name = "cboMaHD";
            this.cboMaHD.Size = new System.Drawing.Size(165, 24);
            this.cboMaHD.TabIndex = 1;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(12, 10);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(83, 17);
            this.label23.TabIndex = 0;
            this.label23.Text = "Mã hóa đơn";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(228, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(228, 17);
            this.label15.TabIndex = 63;
            this.label15.Text = "--------------------------------------------";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(275, 40);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(124, 17);
            this.label14.TabIndex = 62;
            this.label14.Text = "SĐT: 0978788799";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(240, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(206, 17);
            this.label6.TabIndex = 61;
            this.label6.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(306, 6);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 17);
            this.label7.TabIndex = 60;
            this.label7.Text = "DNG";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(438, 256);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(119, 17);
            this.label12.TabIndex = 59;
            this.label12.Text = "Nhân viên: Admin";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(50, 266);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(147, 17);
            this.label11.TabIndex = 58;
            this.label11.Text = "Khách hàng: Khách lẻ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(240, 155);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 17);
            this.label10.TabIndex = 57;
            this.label10.Text = "Ngày:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(438, 187);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 17);
            this.label9.TabIndex = 56;
            this.label9.Text = "Giờ ra:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(258, 129);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(33, 17);
            this.label18.TabIndex = 55;
            this.label18.Text = "Số: ";
            // 
            // Bang_Hoa_Don
            // 
            this.Bang_Hoa_Don.AutoSize = true;
            this.Bang_Hoa_Don.BackColor = System.Drawing.SystemColors.Control;
            this.Bang_Hoa_Don.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Bang_Hoa_Don.ForeColor = System.Drawing.SystemColors.Highlight;
            this.Bang_Hoa_Don.Location = new System.Drawing.Point(89, 74);
            this.Bang_Hoa_Don.Name = "Bang_Hoa_Don";
            this.Bang_Hoa_Don.Size = new System.Drawing.Size(591, 55);
            this.Bang_Hoa_Don.TabIndex = 54;
            this.Bang_Hoa_Don.Text = "HÓA ĐƠN THANH TOÁN";
            this.Bang_Hoa_Don.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txbThanhToan_HD_chitiet
            // 
            this.txbThanhToan_HD_chitiet.Controls.Add(this.panel15);
            this.txbThanhToan_HD_chitiet.Location = new System.Drawing.Point(4, 25);
            this.txbThanhToan_HD_chitiet.Name = "txbThanhToan_HD_chitiet";
            this.txbThanhToan_HD_chitiet.Padding = new System.Windows.Forms.Padding(3);
            this.txbThanhToan_HD_chitiet.Size = new System.Drawing.Size(776, 741);
            this.txbThanhToan_HD_chitiet.TabIndex = 4;
            this.txbThanhToan_HD_chitiet.Text = "Thanh toán hóa đơn chi tiết";
            this.txbThanhToan_HD_chitiet.UseVisualStyleBackColor = true;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.panel16);
            this.panel15.Controls.Add(this.tbMaHH);
            this.panel15.Controls.Add(this.label37);
            this.panel15.Controls.Add(this.label36);
            this.panel15.Controls.Add(this.label32);
            this.panel15.Controls.Add(this.label33);
            this.panel15.Controls.Add(this.label34);
            this.panel15.Controls.Add(this.label35);
            this.panel15.Location = new System.Drawing.Point(3, 6);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(767, 679);
            this.panel15.TabIndex = 0;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Location = new System.Drawing.Point(67, 215);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(640, 211);
            this.panel16.TabIndex = 71;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.panel18);
            this.panel17.Controls.Add(this.panel19);
            this.panel17.Controls.Add(this.panel20);
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(640, 263);
            this.panel17.TabIndex = 2;
            this.panel17.Paint += new System.Windows.Forms.PaintEventHandler(this.panel17_Paint);
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.numericUpDown3);
            this.panel18.Controls.Add(this.label38);
            this.panel18.Location = new System.Drawing.Point(3, 107);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(634, 46);
            this.panel18.TabIndex = 3;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(157, 15);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(139, 22);
            this.numericUpDown3.TabIndex = 2;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(3, 11);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(105, 24);
            this.label38.TabIndex = 0;
            this.label38.Text = "Số lượng:";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.numericUpDown4);
            this.panel19.Controls.Add(this.lbThanhTien);
            this.panel19.Location = new System.Drawing.Point(3, 159);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(634, 46);
            this.panel19.TabIndex = 3;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(157, 15);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(139, 22);
            this.numericUpDown4.TabIndex = 3;
            // 
            // lbThanhTien
            // 
            this.lbThanhTien.AutoSize = true;
            this.lbThanhTien.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbThanhTien.Location = new System.Drawing.Point(3, 11);
            this.lbThanhTien.Name = "lbThanhTien";
            this.lbThanhTien.Size = new System.Drawing.Size(118, 24);
            this.lbThanhTien.TabIndex = 0;
            this.lbThanhTien.Text = "Thành tiền:";
            this.lbThanhTien.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.textBox9);
            this.panel20.Controls.Add(this.lbSoBan);
            this.panel20.Location = new System.Drawing.Point(3, 55);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(634, 46);
            this.panel20.TabIndex = 2;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(148, 13);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(483, 22);
            this.textBox9.TabIndex = 1;
            // 
            // lbSoBan
            // 
            this.lbSoBan.AutoSize = true;
            this.lbSoBan.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSoBan.Location = new System.Drawing.Point(10, 10);
            this.lbSoBan.Name = "lbSoBan";
            this.lbSoBan.Size = new System.Drawing.Size(83, 24);
            this.lbSoBan.TabIndex = 0;
            this.lbSoBan.Text = "Số bàn:";
            this.lbSoBan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbMaHH
            // 
            this.tbMaHH.Location = new System.Drawing.Point(302, 135);
            this.tbMaHH.Name = "tbMaHH";
            this.tbMaHH.Size = new System.Drawing.Size(127, 22);
            this.tbMaHH.TabIndex = 70;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(269, 140);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(33, 17);
            this.label37.TabIndex = 69;
            this.label37.Text = "Số: ";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.SystemColors.Control;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label36.Location = new System.Drawing.Point(65, 77);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(642, 44);
            this.label36.TabIndex = 68;
            this.label36.Text = "THANH TOÁN HÓA ĐƠN CHI TIẾT";
            this.label36.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(252, 60);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(228, 17);
            this.label32.TabIndex = 67;
            this.label32.Text = "--------------------------------------------";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(299, 43);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(124, 17);
            this.label33.TabIndex = 66;
            this.label33.Text = "SĐT: 0978788799";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(264, 26);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(206, 17);
            this.label34.TabIndex = 65;
            this.label34.Text = "ĐC: Số 05 - Đường Đảo Xanh 1";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(330, 9);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(39, 17);
            this.label35.TabIndex = 64;
            this.label35.Text = "DNG";
            // 
            // fAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 794);
            this.Controls.Add(this.tcBill);
            this.Name = "fAdmin";
            this.Text = "Admin";
            this.tbBan.ResumeLayout(false);
            this.tbBan.PerformLayout();
            this.panel21.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.tpFood.ResumeLayout(false);
            this.tpFood.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvFood)).EndInit();
            this.tcBill.ResumeLayout(false);
            this.tbCategory.ResumeLayout(false);
            this.tbCategory.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDonBanHang)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.txbThanhToan_HD_chitiet.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabPage tbBan;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label txbTableNumber;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TextBox txbtxbTableName1;
        private System.Windows.Forms.Label txbTableName;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Button btnViewTable;
        private System.Windows.Forms.Button btnEditTable;
        private System.Windows.Forms.Button btnDeleteTable;
        private System.Windows.Forms.Button btnAddTable;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tpFood;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txbSearchFoodName;
        private System.Windows.Forms.Button btnSearchFood;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txbTenMon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnShowFood;
        private System.Windows.Forms.Button btnEditFood;
        private System.Windows.Forms.Button btnDeleteFood;
        private System.Windows.Forms.Button btnAddFood;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dtgvFood;
        private System.Windows.Forms.TabControl tcBill;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label txbStatus;
        private System.Windows.Forms.TabPage tbCategory;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DataGridView dgvHoaDonBanHang;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ComboBox cboGiamGia;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cboDonGia;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboSoLuong;
        private System.Windows.Forms.ComboBox cboTenHang;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboMahang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cboMaHD;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label Bang_Hoa_Don;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TabPage txbThanhToan_HD_chitiet;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label lbThanhTien;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label lbSoBan;
        private System.Windows.Forms.TextBox tbMaHH;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel21;
    }
}