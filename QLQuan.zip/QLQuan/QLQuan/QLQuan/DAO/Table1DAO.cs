﻿using QLQuan.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQuan.DAO
{
    public class Table1DAO
    {
        private static Table1DAO instance;
        public static Table1DAO Instance
        {
            get { if (instance == null) instance = new Table1DAO(); return Table1DAO.instance; }
            private set { Table1DAO.instance = value; }
        }
        public static int TableWildth = 100;
        public static int TableHeight = 100;
        public List<Table> LoadTableList()
        {
            List<Table> tableList = new List<Table>();
            DataTable data = DataProvider.Instance.ExecuteQuery("select * from BAN");
            foreach (DataRow item in data.Rows)
            {
                Table table = new Table(item);
                tableList.Add(table);
            }
            return tableList;
        }
    }
}
