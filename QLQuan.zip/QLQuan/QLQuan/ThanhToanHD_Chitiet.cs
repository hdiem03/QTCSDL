﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLQuan
{
    public partial class ThanhToanHD_Chitiet : Form
    {
        public ThanhToanHD_Chitiet()
        {
            InitializeComponent();
        }

        private void Bang_Hoa_Don_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
