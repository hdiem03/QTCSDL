﻿
using QLQuan.DAO;
using QLQuan.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Menu = QLQuan.DTO.Menu;

namespace QLQuan
{
    public partial class fQuanLy : Form
    {

        public fQuanLy()
        {
            InitializeComponent();
            LoadTable();
            LoadFoodList();
        }
        #region Method
        void LoadFoodList()
        {
            List<Food> listFood = FoodDAO.Instance.GetListFood();
            cbFood.DataSource = listFood;
            cbFood.DisplayMember = "TenMon";
        }
        //void LoadFood()
        //{
        //    List<Food> listMON = FoodDAO.Instance.GetFoodBy(tenmon);
        //    cbFood.DataSource = listMON;
        //    cbFood.DisplayMember = "TenMon";
        //}
        void LoadTable()
        {
            List<Table> tableList = TableDAO.Instance.LoadTableList();
            foreach (Table item in tableList)
            {
                Button btn = new Button() { Width = TableDAO.TableWildth, Height = TableDAO.TableHeight };
                btn.Text = item.MaBan + Environment.NewLine + item.SoBan + Environment.NewLine + item.TinhTrang;
                switch (item.TinhTrang)
                {
                    case "Trống":
                        btn.BackColor = Color.White;
                        break;
                    default:
                        btn.BackColor = Color.LightGreen;
                        break;

                }
                btn.Click += btn_Click1;
                btn.Tag = item;
                flpTable.Controls.Add(btn);


            }
        }
        void ShowBill1(int soban)
        {
            lsbBill.Items.Clear();
             List<BillInfo1> listbillInfo1 = BillInfo1DAO.Instance.GetListBillInfo1(Bill1DAO.Instance.GetBillSoBanByTableSoBan1(soban));
            float ThanhTien = 0;
            foreach (BillInfo1 item1 in listbillInfo1)
            {

                ListViewItem lsvItem1 = new ListViewItem(item1.MaHoaDon.ToString());
                lsvItem1.SubItems.Add(item1.TenMon.ToString());
                lsvItem1.SubItems.Add(item1.SoLuong.ToString());
                lsvItem1.SubItems.Add(item1.ThanhTien.ToString());
                ThanhTien += item1.ThanhTien;
                lsbBill.Items.Add(lsvItem1);
            }
            CultureInfo culture = new CultureInfo("vi-VN");

            txtTotalThanhTien.Text = ThanhTien.ToString("c", culture);
        }

   
        #region Events
        void btn_Click1(object sender, EventArgs e)
        {
            int soban = ((sender as Button).Tag as Table).SoBan;
            lsbBill.Tag = (sender as Button).Tag;
            ShowBill1(soban);
        }

        private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void thôngTinCáNhânToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAccountProfile f = new fAccountProfile();
            f.ShowDialog();
        }

        private void adminToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void bánToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fAdmin f = new fAdmin();
            f.ShowDialog();
        }

        private void flpTable_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flTableQLyBan_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtTotalThanhTien_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbFood_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void cbFood_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            //string str;
            //str = "select TenMon from Mon where TenMon=N'"+ cbFood.SelectedValue+ "'";
            //ComboBox cb = sender as ComboBox;
            //if (cb.SelectedItem == null)
            //    return;
            //Food selected = cb.SelectedItem as Food;
            //LoadFoodList();
        }
        #endregion


        private void btnCheckOut_Click(object sender, EventArgs e)
        {

            Table table = lsbBill.Tag as Table;
            int SoBan = Bill1DAO.Instance.GetBillSoBanByTableSoBan1(table.SoBan);
            if(SoBan !=-1)
            {
                if (MessageBox.Show("Bạn có chắc thanh toán hóa đơn cho bàn " + table.SoBan, "Thông báo", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
                {
                    Bill1DAO.Instance.Checkout(SoBan);
                    ShowBill1(table.SoBan);
                } 
                    
            }    

        }

        private void btnAddFood_Click(object sender, EventArgs e)
        {
            //if (lsbBill.Tag == null)
            //{
            //    // Log hoặc hiển thị thông báo để xác định tại sao lsbBill.Tag là null
            //    Console.WriteLine("lsbBill.Tag is null.");
            //    MessageBox.Show("Table is null. Please initialize it before adding food.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}
            //if (lsbBill == null || lsbBill.Tag == null)
            //{
            //    // Xử lý khi lsbBill hoặc lsbBill.Tag là null
            //    return;
            //}

            // Tiếp tục xử lý bình thường
            Table table = lsbBill.Tag as Table;
            //if (table == null)
            //{
            //    // Xử lý khi table là null
            //    return;
            //}
            //Table table = lsbBill.Tag as Table;
            int soban = Bill1DAO.Instance.GetBillSoBanByTableSoBan1(table.SoBan);
            //int soban = table.SoBan;
            //string tenmon = (cbFood.SelectedItem as Food).TenMon;
            string tenmon = (cbFood.SelectedItem as Food).TenMon;
            //if (tenmon==null)
            //{
            //    //return;
            //}    
            int soluong = (int)nmFoodCount.Value;
            //float ThanhTien = (float) nmThanhTien.Value;
            if (soban == -1)
            {
                Bill1DAO.Instance.InsertBill(table.SoBan);
                BillInfo1DAO.Instance.InsertBillInfo(Bill1DAO.Instance.GetMaxIDBill(), tenmon, 1, soluong, null);
            }
            else
            {
                BillInfo1DAO.Instance.InsertBillInfo(soban, tenmon, 1, soluong, null);
            }
            ShowBill1(table.SoBan);

            //        textMDH.Enabled = true; // Cho phép nhập mới
            //        textMDH.Focus();
            //        LoadDataGridView();

            //        string sql;
            //        sql = "SELECT MaDatHang FROM MUA WHERE MaDatHang=N'" + textMDH.Text + "'";
            //        if (!Function.CheckKey(sql))
            //        {
            //            // ... (Phần code thêm thông tin mới vào bảng MUA)

            //            sql = "INSERT INTO MUA(MaDatHang, MaNCC, MaNV, NgayMuaHang, TongTienHH) VALUES (N'" + textMDH.Text.Trim() + "', N'" + comboNCC.SelectedValue + "', N'" + comboNV.SelectedValue + "', '" + dateNgaymua.Value + "', N'" + texttongtien.Text + "')";
            //            Function.RunSQL(sql);
            //            LoadDataGridView();
            //        }

            //        // Kiểm tra và thêm thông tin các mặt hàng
            //        if (comboHH.Text.Trim().Length == 0)
            //        {
            //            MessageBox.Show("Bạn phải nhập mã hàng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //            comboHH.Focus();
            //            return;
            //        }
            //        if ((textSLCT.Text.Trim().Length == 0) || (textSLCT.Text == "0"))
            //        {
            //            MessageBox.Show("Bạn phải nhập số lượng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //            textSLCT.Text = "";
            //            textSLCT.Focus();
            //            return;
            //        }

            //        sql = "SELECT MaHH FROM MUA_CHI_TIET WHERE MaHH=N'" + comboHH.SelectedValue + "' AND MaDatHang = N'" + textMDH.Text.Trim() + "'";
            //        if (Function.CheckKey(sql))
            //        {
            //            // Nếu mã hàng hóa đã tồn tại trong đơn hàng, cập nhật số lượng và thành tiền

            //            // Lấy giá trị số lượng và thành tiền hiện tại từ bảng
            //            string currentQuantitySQL = "SELECT SoLuongHH, ThanhTienHH FROM MUA_CHI_TIET WHERE MaHH=N'" + comboHH.SelectedValue + "' AND MaDatHang = N'" + textMDH.Text.Trim() + "'";
            //            DataTable currentValues = Function.GetDataToTable(currentQuantitySQL);

            //            double currentQuantity = Convert.ToDouble(currentValues.Rows[0]["SoLuongHH"]);
            //            double currentTotal = Convert.ToDouble(currentValues.Rows[0]["ThanhTienHH"]);

            //            // Tính giá trị mới của số lượng và thành tiền
            //            double newQuantity = currentQuantity + Convert.ToDouble(textSLCT.Text);
            //            double newTotal = currentTotal + Convert.ToDouble(textthanhtien.Text);

            //            string sqlUpdate = "UPDATE MUA_CHI_TIET SET SoLuongHH = " + newQuantity + ", ThanhTienHH = " + newTotal +
            //                               " WHERE MaDatHang = N'" + textMDH.Text.Trim() + "' AND MaHH = N'" + comboHH.SelectedValue + "'";
            //            Function.RunSQL(sqlUpdate);
            //        }
            //        else
            //        {
            //            // Nếu chưa tồn tại, thực hiện thêm mới vào bảng
            //            string sqlInsert = "INSERT INTO MUA_CHI_TIET(MaDatHang, MaHH, SoLuongHH, ThanhTienHH) VALUES (N'" + textMDH.Text.Trim() + "', N'" + comboHH.SelectedValue + "', " + textSLCT.Text + ", " + textthanhtien.Text + ")";
            //            Function.RunSQL(sqlInsert);
            //        }

            //        // Code để kiểm tra và lấy giá trị tổng tiền mới từ bảng MUA_CHI_TIET
            //        double tong = Convert.ToDouble(Function.GetFieldValues("SELECT SUM(ThanhTienHH) FROM MUA_CHI_TIET WHERE MaDatHang = '" + textMDH.Text.Trim() + "'"));

            //        // Cập nhật giá trị tổng tiền mới vào bảng MUA
            //        string updateTotalSQL = "UPDATE MUA SET TongTienHH = " + tong + " WHERE MaDatHang = '" + textMDH.Text.Trim() + "'";
            //        texttongtien.Text = tong.ToString();
            //        Function.RunSQL(updateTotalSQL);
            //        LoadDataGridView();
            //    }
            //}
        }
        #endregion

        private void lsbBill_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

 
