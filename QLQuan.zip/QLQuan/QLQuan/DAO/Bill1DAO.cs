﻿using QLQuan.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQuan.DAO
{
    public class Bill1DAO
    {
        private static Bill1DAO instance;
        //private DataTable DataTable;

        public static Bill1DAO Instance
        {
            get { if (instance == null) instance = new Bill1DAO(); return Bill1DAO.instance; }
            private set { Bill1DAO.instance = value; }
        }
        /// <summary>
        /// Thành công thì lấy ra được số bàn
        /// thất bại thì sẽ hiện -1
        /// </summary>
        private Bill1DAO() { }
        public int GetBillSoBanByTableSoBan1(int soban)
        {
            DataTable data = DataProvider.Instance.ExecuteQuery("select *from dbo.THANH_TOAN_HD where SoBan = '" + soban + "'");
            if (data.Rows.Count > 0)
            {
                Bill1 bill1 = new Bill1(data.Rows[0]);
                return bill1.SoBan;
            }
            return -1;
        }
        public void Checkout(int soban)
        {
            string query = "update BAN set TinhTrang='Đang phục vụ' where SoBan=" + soban;
            DataProvider.Instance.ExecuteNonQuery(query);
        }
        public void InsertBill()
        {
            DataProvider.Instance.ExecuteNonQuery("exec USP_InsertBill @soban",new object[] {mahoadon});
        }
        public int GetMaxIDBill()
        {
            try
            {
                return(int)DataProvider.Instance.ExecuteScalar("select Max(MaHoaDon)");
            }
            catch
            {
                return 1;
            }
            
        }
    }
}

