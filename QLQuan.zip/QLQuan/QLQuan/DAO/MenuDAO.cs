﻿using QLQuan.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQuan.DAO
{
    public class MenuDAO
    {
        private static MenuDAO instance;
        public static MenuDAO Instance
        {
            get { if (instance == null) instance = new MenuDAO();  return MenuDAO.instance; }
            private set { MenuDAO.instance = value; }
        }
        private MenuDAO() { }
        public List<Menu>GetListMenuByTable(int soban)
        {
            List<Menu> listMenu = new List<Menu>();
            string query = "select b.SoBan,c.TenMon,a.SoLuong,c.GiaTien ,c.GiaTien*a.SoLuong as N'Tổng từng món' from dbo.THANH_TOAN_HD_CHI_TIET as a, dbo.THANH_TOAN_HD as b, dbo.MON as c where a.MaHoaDon = b.MaHoaDon and a.TenMon = c.TenMon and b.SoBan = " +soban;
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach(DataRow item in data.Rows)
            {
                Menu menu = new Menu(item);
                listMenu.Add(menu);
            }    
            return listMenu;
        }
    }
}
