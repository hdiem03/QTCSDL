﻿using QLQuan.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQuan.DAO
{
    public class BillInfo1DAO
    {
        private static BillInfo1DAO instance;
        public static BillInfo1DAO Instance
        {
            get { if (instance == null) instance = new BillInfo1DAO(); return BillInfo1DAO.instance; }
            private set { BillInfo1DAO.instance = value; }
        }
        private BillInfo1DAO() { }
        //public List<BillInfo1> GetListBillInfo1(int  mahoadon)
        //{
        //    List<BillInfo1> listBillInfo1 = new List<BillInfo1>();
        //    DataTable data = DataProvider.Instance.ExecuteQuery("select MaHoaDon, TenMon, SoLuong from dbo.THANH_TOAN_HD_CHI_TIET where MaHoaDon= " + mahoadon);
        //    foreach (DataRow item in data.Rows)
        //    {
        //        BillInfo1 info = new BillInfo1(item);
        //        listBillInfo1.Add(info);
        //    }
        //    return listBillInfo1;
        //}
        public List<BillInfo1> GetListBillInfo1(int mahoadon)
        {
            List<BillInfo1> listBillInfo1 = new List<BillInfo1>();
            // Sửa truy vấn để lấy thêm giá (DonGia) của mỗi món
            DataTable data = DataProvider.Instance.ExecuteQuery("SELECT c.MaHoaDon, c.TenMon, c.SoLuong, m.GiaTien " +
                                                                "FROM dbo.THANH_TOAN_HD_CHI_TIET c " +
                                                                "INNER JOIN dbo.MON m ON c.TenMon = m.TenMon " +
                                                                "WHERE c.MaHoaDon = " + mahoadon);

            foreach (DataRow item in data.Rows)
            {
                BillInfo1 info = new BillInfo1(item);
                // Tính toán thành tiền và gán vào đối tượng BillInfo1
                info.ThanhTien = Convert.ToInt32(item["SoLuong"]) * Convert.ToInt32(item["GiaTien"]);
                listBillInfo1.Add(info);
            }

            return listBillInfo1;

        }
        public void InsertBillInfo(int mahoadon ,string tenmon ,int @soluong ,int thanhtien, object p)
        {
            DataProvider.Instance.ExecuteNonQuery(" exec USP_InsertBillInfo @mahoadon int, @tenmon nvarchar(100),@soluong int, @thanhtien int",new object[] { mahoadon,tenmon,soluong,thanhtien});
        }
    }
}
