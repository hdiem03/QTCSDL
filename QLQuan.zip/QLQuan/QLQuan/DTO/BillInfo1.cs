﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQuan.DTO
{
    public class BillInfo1
    {
        public BillInfo1(int mahoadon,int soban, DateTime? giovao, DateTime? giora, string makh, string manv)
        {
            this.MaHoaDon = mahoadon;
            this.SoBan = soban;
            this.GioVao = giovao;
            this.GioRa = giora;
            this.MaKH = makh;
            this.MaNV = manv;

        }
        public BillInfo1(DataRow row)
        {
            this.MaHoaDon = (int)row["mahoadon"];
            this.SoBan = (int)row["soban"];
            this.GioVao = (DateTime?)row["giovao"];
            this.GioRa = (DateTime?)row["giora"];
            this.MaKH = row["makh"].ToString();
            this.MaNV = row["manv"].ToString();
        }
        private DateTime? giovao;
        public DateTime? GioVao
        {
            get { return giovao; }
            set { giovao = value; }

        }
        private DateTime? giora;
        public DateTime? GioRa
        {
            get { return giora; }
            set { giora = value; }

        }
        private int soban;
        public int SoBan
        {
            get { return soban; }
            set { soban = value; }

        }
        private int mahoadon;
        public int MaHoaDon
        {
            get { return mahoadon; }
            set { mahoadon = value; }

        }
        private string makh;
        public string MaKH
        {
            get { return makh; }
            set { makh = value; }

        }
        private string manv;
        public string MaNV
        {
            get { return manv; }
            set { manv = value; }

        }
    }
}
