﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQuan.DTO
{
    public class Table
    {
        public Table(string maban,int soban)
        {
            this.MaBan = maban;
            this.SoBan = soban;
        }
        public Table(DataRow row)
        {
            this.MaBan = row["maban"].ToString();
            this.SoBan = (int)row["soban"];
        }
        private string maban;
        public string MaBan
        {
            get { return maban; }
            set { maban = value; }
        }
        private int soban;
        public int SoBan
        {
            get { return soban; }
            set { soban = value; }
        }

    }
}
