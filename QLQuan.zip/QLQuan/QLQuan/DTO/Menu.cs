﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQuan.DTO
{
    public class Menu
    {
        public Menu(DateTime?giora,DateTime? giovao,int soban, string tenmon, string makh, string manv,int totalPrice =0)
        {
            this.GioRa = giora;
            this.GioVao = giovao;
            this.soban = SoBan;
            this.tenmon = TenMon;
            this.manv = MaNV;
            this.makh = MaKH;
            this.TotalPrice = totalPrice;
        }
        public Menu(DataRow row)
        {
            this.SoBan = (int)row["soban"];
            this.GioVao = (DateTime?)row["giovao"];
            this.GioRa = (DateTime?)row["giora"];
            this.TenMon = row["tenmon"].ToString();
            this.MaKH = row["makh"].ToString();
            this.MaNV = row["manv"].ToString();
            this.TotalPrice = (int)row["totalPrice"];
        }
        private int totalPrice;
        public int TotalPrice
        {
            get { return totalPrice; }
            private set { totalPrice = value; }
        }
        private DateTime? GioRa;
        private DateTime? GioVao;
        private int soban;
        public int SoBan
        {
            get { return soban; }
            private set { soban = value; }
        }
        private string tenmon;
        public string TenMon
        {
            get { return tenmon; }
            private set { tenmon = value; }
        }
        private string makh;
        public string MaKH
        {
            get { return makh; }
            private set { makh = value; }
        }
        private string manv;
        public string MaNV
        {
            get { return manv; }
            private set {manv = value; }
        }

    }
}
