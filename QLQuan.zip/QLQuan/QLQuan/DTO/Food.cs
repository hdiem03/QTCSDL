﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLQuan.DTO
{
    public class Food
    {
        public Food(string tenmon, int giatien)
        {
            this.TenMon = tenmon;
            this.GiaTien = giatien;
        }
        public Food(DataRow row)
        {
            this.TenMon = row["tenmon"].ToString();
            this.GiaTien =(int)row["giatien"];
        }
        private string tenmon;
        public string TenMon
        {
            get { return tenmon; }
            private set { tenmon = value; }
        }
        private int giatien;
        public int GiaTien
        {
            get { return giatien; }
            private set { giatien = value; }
        }
    }

}
